
<?php
@session_start();
include_once("db/conexion.php");

$con = obtener_conexion();
$correo = $_SESSION["correo"];

$idProyecto = $_GET["id"];
?>
<!DOCTYPE html>
    <html lang="en">
    <head>
    <!-- <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> -->
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="EstilosRiesgosProyecto.css">
    <title>Prueba</title>
    </head>
<body>
 <nav class="navbar navbar-light bg-light" id="barraNavegacion" >
        <a class="navbar-brand" id="imagenLogo"  href="AreaPersonal.php"> <img src="imagensinfondo.png" alt="" srcset="" id="imagenLogo1"></a>
        <a class="navbar-brand" id="logo" href="AreaPersonal.php"> Detección de los Riesgos <br>
        <p id="subtitulo">En las etapas de pre análisis y análisis</p></a>
        <form class="form-inline" id="cajitaboton">
            <button class="btn btn-secondary my-2 my-sm-0" type="submit"> <a href="index.php" id="linkInicio">Cerrar Sesión</a></button>
        </form>
    </nav>
<div style="height: 75px;"></div>
<?php 
    $medio = 0;
    $alto =0;
?>
<table class="table table-bordered" id="tablaRiesgos">
            <thead>
                <tr>
                    <th scope="col">Riesgo</th>
                    <th scope="col">Impacto</th>
                    <th scope="col">Plan de Mitigación</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    //consulta a la base de datos
                    $sql = "SELECT * FROM riesgosproyectos 
                            WHERE Correo='$correo' AND id_proyecto='$idProyecto'";
                   
                    $con = obtener_conexion();
                    $resultado = mysqli_query($con,$sql);

                    while($filas=mysqli_fetch_array($resultado)){ //mientras halla datos en la variable resultados 
                        ?>
                        <tr>
                            <td><?php echo $filas['riesgo']?></td>
                            <td><?php if( $filas['impacto'] == "Medio"){ 
                                 $medio++;
                                 echo '<span style="color: Orange; font-weight: bold;">'. $filas['impacto'] . '</span>';
                                 }else{
                                 $alto++;
                                    echo '<span style="color: Red; font-weight: bold;">'. $filas['impacto'] . '</span>';
                                 }?></td>
                            <td><?php echo $filas['planMitigacion']?></td>
                        </tr>
                <?php }?> 
            </tbody>
            <p style="background: Orange; color: White; text-align: center; display: inline-block; width: 15%; margin-left: 60%; border-radius: 10px; padding: 5px;">Riesgos Medios: <?php echo $medio;?> </p>
            <p style="display: inline-block; width: 5%;"></p>
            <p style="background: Red; color: White; text-align: center; display: inline-block; width: 15%; border-radius: 10px; padding: 5px;">Riesgos Altos: <?php echo $alto;?> </p>

        </table>
        <a href="AreaPersonal.php" name="salida" id="salida" class="btn btn-primary">Página Inicio</a>
        <div style="height: 75px;"></div>

</body>
</html>
