<?php
    @session_start();
    /* $user = "root";
    $pass = "";
    $server = "localhost";
    $db = "proyecto"; */
    $user = "fqosfnlaajzchx";
    $pass= "9b512dc0fd60630edf30d93428c5763b97c698be10bfbf5a2960d1e451564e82";
    $server = "ec2-52-73-247-67.compute-1.amazonaws.com";
    $db = "dfbehudhjnjpgq";
    $con= mysqli_connect($server,$user,$pass) or die("Error al conectar a la BD".mysql_error()); //variable que contiene la conexión con la bd
    mysqli_select_db($con,$db);
   
    //var_dump($_POST);
    if(isset($_POST['empresa'])){
        //seleccionar variables 
        $correo = $_SESSION["correo"];
        $empresa = $_POST["empresa"];
        $añosEmpresa = $_POST["años"];
        $empleados = $_POST['personas'];
        $capacitaciones = $_POST['capacitacionesPersonal'];
 
        $sql = "INSERT INTO empresa (Correo, NombreEmpresa, Empleados, Años_empresa, Capacitaciones) VALUES ('$correo','$empresa','$empleados','$añosEmpresa','$capacitaciones')";
        //ejecutamos la sentencia sql
        $ejecutar = $con->query($sql);
        $id_empresa = $con->insert_id; //el ultimo ID que acabe de crear
        
        $cantnuevos = intval($_POST["hddcantnuevos"]);
        if ($cantnuevos > 0) {
            for ($i = 0; $i < $cantnuevos; $i++) {
                $lenguaje = $_POST['lenguaje'.$i];
                $puntaje = $_POST['selcalificacion'.$i];
                if($lenguaje!="" && $puntaje!=""){
                    $sql1= "INSERT INTO lenguajes(id_empresa, Lenguajes,Puntuacion) VALUES($id_empresa,'$lenguaje', '$puntaje')";
                    $ejecutar = $con->query($sql1);
                }
            }
        }
        $servicio1 = $_POST['hddservicio1'];
        $nombreservicio1= $_POST['hddnombreservicio1'];
        if($servicio1 ==1){
            $ficha= "INSERT INTO servicios (id_empresa, Servicio) VALUES ($id_empresa, '$nombreservicio1')";                
            $ejecutar = $con->query($ficha);               
        }
        $servicio2 = $_POST['hddservicio2'];
        $nombreservicio2= $_POST['hddnombreservicio2'];
        if($servicio2 ==1){
            $ficha= "INSERT INTO servicios (id_empresa, Servicio) VALUES ($id_empresa, '$nombreservicio2')";                
            $ejecutar = $con->query($ficha);               
        }
        $servicio3 = $_POST['hddservicio3'];
        $nombreservicio3= $_POST['hddnombreservicio3'];
        if($servicio3 ==1){
            $ficha= "INSERT INTO servicios (id_empresa, Servicio) VALUES ($id_empresa, '$nombreservicio3')";                
            $ejecutar = $con->query($ficha);               
        }
        $servicio4 = $_POST['hddservicio4'];
        $nombreservicio4= $_POST['hddnombreservicio4'];
        if($servicio4 ==1){
            $ficha= "INSERT INTO servicios (id_empresa, Servicio) VALUES ($id_empresa, '$nombreservicio4')";                
            $ejecutar = $con->query($ficha);               
        }
        $servicio5 = $_POST['hddservicio5'];
        $nombreservicio5= $_POST['hddnombreservicio5'];
        if($servicio5 ==1){
            $ficha= "INSERT INTO servicios (id_empresa, Servicio) VALUES ($id_empresa, '$nombreservicio5')";                
            $ejecutar = $con->query($ficha);               
        }
        $servicio6 = $_POST['hddservicio6'];
        $nombreservicio6= $_POST['hddnombreservicio6'];
        if($servicio6 ==1){
            $ficha= "INSERT INTO servicios (id_empresa, Servicio) VALUES ($id_empresa, '$nombreservicio6')";                
            $ejecutar = $con->query($ficha);               
        }
        $servicio7 = $_POST['hddservicio7'];
        $nombreservicio7= $_POST['hddnombreservicio7'];
        if($servicio7 ==1){
            $ficha= "INSERT INTO servicios (id_empresa, Servicio) VALUES ($id_empresa, '$nombreservicio7')";                
            $ejecutar = $con->query($ficha);               
        }

        $lenguaje1 = $_POST['hddlenguaje1'];
        $nombrelenguaje1 = $_POST['hddnombrelenguaje1'];
        $puntaje1 = $_POST['selcalificacion1'];
        echo("l1=".$lenguaje1);
        if($lenguaje1 ==1){
            $ficha= "INSERT INTO lenguajes (id_empresa, Lenguajes, Puntuacion) VALUES ($id_empresa, '$nombrelenguaje1', '$puntaje1')";                
            $ejecutar = $con->query($ficha);
            echo(" ".$ficha);
        }
        $lenguaje2 = $_POST['hddlenguaje2'];
        $nombrelenguaje2 = $_POST['hddnombrelenguaje2'];
        $puntaje2 = $_POST['selcalificacion2'];
        if($lenguaje2 ==1){
            $ficha= "INSERT INTO lenguajes (id_empresa, Lenguajes, Puntuacion) VALUES ($id_empresa, '$nombrelenguaje2', '$puntaje2')";                
            $ejecutar = $con->query($ficha);               
        }
        $lenguaje3 = $_POST['hddlenguaje3'];
        $nombrelenguaje3 = $_POST['hddnombrelenguaje3'];
        $puntaje3 = $_POST['selcalificacion3'];
        if($lenguaje3 ==1){
            $ficha= "INSERT INTO lenguajes (id_empresa, Lenguajes, Puntuacion) VALUES ($id_empresa, '$nombrelenguaje3', '$puntaje3')";                
            $ejecutar = $con->query($ficha);                
        }
        $lenguaje4 = $_POST['hddlenguaje4'];
        $nombrelenguaje4 = $_POST['hddnombrelenguaje4'];
        $puntaje4 = $_POST['selcalificacion4'];
        if($lenguaje4 ==1){
            $ficha= "INSERT INTO lenguajes (id_empresa, Lenguajes, Puntuacion) VALUES ($id_empresa, '$nombrelenguaje4', '$puntaje4')";                
            $ejecutar = $con->query($ficha);              
        }
        $lenguaje5 = $_POST['hddlenguaje5'];
        $nombrelenguaje5 = $_POST['hddnombrelenguaje5'];
        $puntaje5 = $_POST['selcalificacion5'];
        if($lenguaje5 == 1){
            $ficha= "INSERT INTO lenguajes (id_empresa, Lenguajes, Puntuacion) VALUES ($id_empresa, '$nombrelenguaje5', '$puntaje5')";                
            $ejecutar = $con->query($ficha);                
        }
        $lenguaje6 = $_POST['hddlenguaje6'];
        $nombrelenguaje6 = $_POST['hddnombrelenguaje6'];
        $puntaje6 = $_POST['selcalificacion6'];
        if($lenguaje6 == 1){
            $ficha= "INSERT INTO lenguajes (id_empresa, Lenguajes, Puntuacion) VALUES ($id_empresa, '$nombrelenguaje6', '$puntaje6')";                
            $ejecutar = $con->query($ficha);                
        }
       
        if(!$ejecutar){
            echo "Debes Iniciar Sesión"; 
        }
        $_SESSION['mensaje'] = 'Datos guardados satisfactoriamente';
        $_SESSION['tipo_mensaje'] ='success';
        header("Location: AreaPersonal.php");        
    }       
?>