<?php
    @session_start();
    //include_once("RiesgosProyecto.php");

    $Correo = $_SESSION["correo"];
    //$id = $_SESSION['id'];
    if (isset($_POST["idEmpresa"])) {
        $idEmpresa = $_POST["idEmpresa"];
    } else {
        $idEmpresa = $_GET['id'];
    }
    //$idProyecto = $_GET['id'];
    //include("conexionArea.php");
    include_once("db/conexion.php");
    $con = obtener_conexion();

    if(isset($_POST['calcularRiesgos'])){
        //--------No las nesecito PARA CREAR PROYECTO
        $personas = $_POST['personasDelProyecto'];
        $salarioTotal1 = $Sueldogerente * $gerente;
        $salarioTotal2 = $Sueldoanalistas * $analistas;
        $salarioTotal3 = $Sueldodesarrolladores * $desarrolladores;
        $salarioTotal4 = $Sueldopruebas * $pruebas;
        $gerente = $_POST['selpersonas1'];
        $Sueldogerente = $_POST['selsalario1'];
        $analistas = $_POST['selpersonas2'];
        $Sueldoanalistas = $_POST['selsalario2'];
        $desarrolladores = $_POST['selpersonas3'];
        $Sueldodesarrolladores = $_POST['selsalario3'];
        $pruebas = $_POST['selpersonas4'];
        $Sueldopruebas = $_POST['selsalario4'];
        //------------las necesito PARA CREAR PROYECTO
        $proyecto = $_POST['proyecto'];
        $descripcion = $_POST['descripcionProyecto'];
        $recursoHumano = $_POST['recursoHumano'];
        $conocimientoEquipo = $_POST['conocimientoEquipo'];
        $conocimientoDirector = $_POST['conocimientoDirector'];
        $conocimientoCliente = $_POST['conocimientoCliente'];
        $personas = $_POST['personasDelProyecto'];
        $claridad = $_POST['claridadCliente'];
        $suficiente1 = $_POST['suficientePersonalTiempo'];
        $suficiente2 = $_POST['suficientePersonalPresupuesto'];
        $capacitaciones = $_POST['capacitacionesPersonal'];
        $presupuestoPersonal = $_POST['presupuestoPagoPersonal'];
        $gastos = $_POST['presupuestoGastos'];
        $presupuesto = $_POST['presupuestoProyecto'];
        $tecnologiaCostos = $_POST['CostoTecnologia'];
        $tiempocliente3 = $_POST['tiempoClienteDias'];//
        $tiempoanalisis3 = $_POST['tiempoAnalisisDias']; //
        $tiempodesarrollo3 = $_POST['tiempoDesarrolloDias']; //
        //$actividades = $_POST['actividadesCronograma'];
        $disponibilidad = $_POST['disponibilidadCliente'];
        $intervencion = $_POST['intervencionCliente'];
        $reunion1 = $_POST['tiempoReuniones'];
        $reunion2 = $_POST['CategoriaReuniones'];
        $documentacion = $_POST['documentacion'];
        $almacenamiento = $_POST['AlmacenamientoRequerimientos'];
        $actualizarDocumentos = $_POST['actualizarDocumentacion'];
        $requisitos = $_POST['importanciaRequisitos'];
        $seguimiento = $_POST['seguimientoObjetivos'];
        $actualizar = $_POST['actualizarObjetivos'];
        $acceso = $_POST['accesoInformacion'];
        $desempeño = $_POST['evaluacionDesempeño'];
        $herramientaVersiones = $_POST['versionarCodigo'];
        $herramientaGestion = $_POST['herramientaGestion'];
        $sql = "INSERT INTO proyecto (id_empresa, CorreoEmpresa, Nombre, Descripcion, RecursoHumano, ConocimientoEquipo, ConocimientoDirector, ConocimientoCliente, ClaridadCliente, Personas, 	Gerentes, SueldoGerente, Analistas, SueldoAnalista, Desarrollador, SueldoDesarrollador,
        Pruebas, SueldoPruebas, SuficientePersonalTiempo, SuficientePersonalPresupuesto, Capacitaciones, PresupuestoPersonal, PresupuestoGastos, Presupuesto, CostoTecnologia,  TiempoClienteDias, TiempoAnalisisDias, TiempoDesarrolloDias,
        DisponibilidadCliente, IntervencionCliente, Reuniones, CategoriaReuniones, Documentacion, AlmacenamientoDocumentacion, ActualizarDocumentos, Requerimientos, Seguimiento, ActualizarCambios, AccesoInformacion, EvaluacionDesempeño, HerramientaVersiones, HerramientaGestion)
        Values('$idEmpresa','$Correo', '$proyecto', '$descripcion','$recursoHumano','$conocimientoEquipo','$conocimientoDirector','$conocimientoCliente','$claridad','$personas','$gerente','$Sueldogerente','$analistas','$Sueldoanalistas','$desarrolladores','$Sueldodesarrolladores',
        '$pruebas','$Sueldopruebas','$suficiente1','$suficiente2','$capacitaciones','$presupuestoPersonal','$gastos','$presupuesto','$tecnologiaCostos','$tiempocliente3','$tiempoanalisis3','$tiempodesarrollo3', 
        '$disponibilidad','$intervencion','$reunion1','$reunion2','$documentacion', '$almacenamiento', '$actualizarDocumentos','$requisitos','$seguimiento','$actualizar','$acceso','$desempeño','$herramientaVersiones','$herramientaGestion')";

        $resultado = mysqli_query($con,$sql); 
        $idProyecto = $con->insert_id;
        if(!empty($_POST['check_lista'])) {
            // Contando el numero de input seleccionados "checked" checkboxes.
            $checked_contador = count($_POST['check_lista']);
            echo "<p>Has seleccionado los siguientes ".$checked_contador." opcione(s):</p> <br/>";
            // Bucle para almacenar y visualizar valores activados checkbox.
            foreach($_POST['check_lista'] as $seleccion) {
            echo "<p>".$seleccion ."</p>";
            $sql0= "INSERT INTO tecnologiasproyecto(CorreoEmpresa, IdProyecto, IdEmpresa, Tecnologia) VALUES('$Correo', $idProyecto, $idEmpresa, '$seleccion')";
            $ejecutar = mysqli_query($con,$sql0);  
            }
        }
        $cantnuevos = intval($_POST["hddcantnuevos"]);
        if ($cantnuevos > 0) {
            for ($i = 0; $i < $cantnuevos; $i++) {
                $lenguaje = $_POST['lenguaje'.$i];
                if($lenguaje!=""){
                    $sql1= "INSERT INTO tecnologiasproyecto(CorreoEmpresa, IdProyecto, IdEmpresa, Tecnologia) VALUES('$Correo', $idProyecto, $idEmpresa, '$lenguaje')";
                    $ejecutar = $con->query($sql1);
                }
            }
        }

        if((($conocimientoEquipo == 3) && ($conocimientoDirector == 3)) || (($conocimientoEquipo == 3) && ($conocimientoDirector < 3)) || (($conocimientoEquipo < 3) && ($conocimientoDirector == 3))){
            $riesgo1 = "INSERT INTO riesgosproyectos (Correo, id_empresa, id_proyecto, riesgo , impacto, planMitigacion)
            Values('$Correo','$idEmpresa','$idProyecto','Falta de suficientes habilidades técnicas en el equipo de trabajo','Medio', 'Algunos de los integrantes del equipo de trabajo no cuenta con suficiente conocimiento de las tecnologías, por lo que sería ideal realizar capacitaciones con respecto a las tecnologías que se van a utilizar en la realización de este proyecto.')";
            $guardar1 = mysqli_query($con,$riesgo1); 
        }else if(($conocimientoEquipo < 3) && ($conocimientoDirector < 3)){
            $riesgos1 = "INSERT INTO riesgosproyectos (Correo, id_empresa, id_proyecto, riesgo , impacto, planMitigacion)
            Values('$Correo','$idEmpresa','$idProyecto','Falta de suficientes habilidades técnicas en el equipo de trabajo','Alto','El equipo de trabajo y el director del proyecto deberían tomar capacitación con respecto a la tecnología con la que se va a trabajar, ya que, no es suficiente tener nociones de la tecnología sino que se necesita tener un conocimiento pleno de esta para que se pueda hacer entrega del software en el tiempo establecido.')";
            $guardaar1 = mysqli_query($con,$riesgos1); 
        }
        $contador1=0;
        if($suficiente1 == 'No'){
            $contador1++;
        }if($personas < 4){
            $contador1++;
        }if($contador1==1){
            $riesgo2 = "INSERT INTO riesgosproyectos (Correo, id_empresa, id_proyecto, riesgo , impacto, planMitigacion)
            Values('$Correo','$idEmpresa','$idProyecto','Escasez de personal','Medio', 'Es necesario que el Gerente del Proyecto puede utilizar herramientas manuales o automatizadas para obtener un presupuesto estimado. Las herramientas de asignación pueden ser hojas de cálculo simples o una
            herramienta compleja de estimación del presupuesto. Además tiene que estimar el personal necesario y adecuado para llevar a cabo el proyecto teniendo en cuenta la experiencia y habilidades necesarias para cumplir con las actividades del cronograma del proyecto y  de esta manera entregar el proyecto en el tiempo establecido.')";
            $guardar2 = mysqli_query($con,$riesgo2); 
        } 
        if(($suficiente1 == 'No') && ($personas < 4)){
            $riesgos2 = "INSERT INTO riesgosproyectos (Correo, id_empresa, id_proyecto, riesgo , impacto, planMitigacion)
            Values('$Correo','$idEmpresa','$idProyecto','Escasez de personal','Alto', 'Es necesario que el Gerente del Proyecto puede utilizar herramientas manuales o automatizadas para obtener un presupuesto estimado. Las herramientas de asignación pueden ser hojas de cálculo simples o una
            herramienta compleja de estimación del presupuesto. Además tiene que estimar el personal necesario y adecuado para llevar a cabo el proyecto teniendo en cuenta la experiencia y habilidades necesarias para cumplir con las actividades del cronograma del proyecto y  de esta manera entregar el proyecto en el tiempo establecido.')";
            $guardaar2 = mysqli_query($con,$riesgos2);
        }
        $contador = 0;
        if($herramientaVersiones == 'No'){
            $contador++;
        }if($capacitaciones == 'No'){
            $contador++;
        }if($herramientaGestion == "No"){
            $contador++;
        }
        if($contador <= 2){
            $riesgos3 = "INSERT INTO riesgosproyectos (Correo, id_empresa, id_proyecto, riesgo , impacto, planMitigacion)
            Values('$Correo','$idEmpresa','$idProyecto','Conocimiento inadecuado de las herramientas requeridas','Medio', 'La empresa debe brindar las capacitaciones necesarios para que el equipo de trabajo pueda realizar sus labores de forma eficaz, además la empresa debería emplear herramientas tecnológicas para el control de versiones de código como Git o TortoiseSVN y para la gestión de proyectos como Jira, ya que, son muy conocidas por su eficiencia y son de las más utilizadas en las diferentes empresas de software.')";
            $guardaar3 = mysqli_query($con,$riesgos3);
        }
        if(($capacitaciones == 'No') && ($herramientaVersiones == 'No') && ($herramientaGestion == "No")){
            $riesgo3 = "INSERT INTO riesgosproyectos (Correo, id_empresa, id_proyecto, riesgo , impacto, planMitigacion)
            Values('$Correo','$idEmpresa','$idProyecto','Conocimiento inadecuado de las herramientas requeridas','Alto', 'La empresa debe brindar las capacitaciones necesarios para que el equipo de trabajo pueda realizar sus labores de forma eficaz, además la empresa debería emplear herramientas tecnológicas para el control de versiones de código como Git o TortoiseSVN y para la gestión de proyectos como Jira, ya que, son muy conocidas por su eficiencia y son de las más utilizadas en las diferentes empresas de software.')";
            $guardar3 = mysqli_query($con,$riesgo3); 
        }  
        //$seleccionar3 = "SELECT Riesgo From riesgos Where 'ID' = 4";
        if(($conocimientoCliente == "Medio ( 31% - 60% )") || ($claridad == "Medio (31% - 60%)")){
            $riesgo4 = "INSERT INTO riesgosproyectos (Correo, id_empresa, id_proyecto, riesgo , impacto, planMitigacion)
            Values('$Correo','$idEmpresa','$idProyecto','Falta de acuerdo entre el cliente y el desarrollador','Medio', 'Ya que el cliente no cuenta con una claridad plena de los requerimientos del proyecto y de la tecnología que se va a utilizar. Se considera necesario mantener una comunicación constante con este e Informar al cliente de los próximos pasos y de las tareas pendientes que se van a llevar a cabo, al igual si el Gerente de proyecto considera necesario, sería ideal realizar capacitaciones al cliente acerca de las tecnologías.')";
            $guardar4 = mysqli_query($con,$riesgo4); 
        } if((($conocimientoCliente == "Nulo ( 0% )") || ($conocimientoCliente == "Bajo ( 10% - 30% )")) && ($claridad == "Bajo (10% - 30%)")){
            $riesgos4 = "INSERT INTO riesgosproyectos (Correo, id_empresa, id_proyecto, riesgo , impacto, planMitigacion)
            Values('$Correo','$idEmpresa','$idProyecto','Falta de acuerdo entre el cliente y el desarrollador','Alto','Ya que el cliente no cuenta con una claridad plena de los requerimientos del proyecto y de la tecnología que se va a utilizar. Se considera necesario mantener una comunicación constante con este e Informar al cliente de los próximos pasos y de las tareas pendientes que se van a llevar a cabo, al igual si el Gerente de proyecto considera necesario, sería ideal realizar capacitaciones al cliente acerca de las tecnologías.')";
            $guardaar4 = mysqli_query($con,$riesgos4); 
        }
        $sumaPresupuesto = $gastos + $presupuestoPersonal + $tecnologiaCostos;
        $salarioTotal = $salarioTotal1 + $salarioTotal2 + $salarioTotal3 + $salarioTotal4;
        if(($sumaPresupuesto < $presupuesto) || ($salarioTotal > $presupuestoPersonal)){
            $riesgo5 = "INSERT INTO riesgosproyectos (Correo, id_empresa, id_proyecto, riesgo , impacto, planMitigacion)
            Values('$Correo','$idEmpresa','$idProyecto','Presupuesto poco realista','Alto','Cuando no se cuenta con suficientes recursos económicos para la realización del proyecto, esto conlleva el retraso de la entrega de este. Es por lo cual, que es necesario que el Gerente de proyectos, cuente con herramientas tecnológicas, métricas o hojas de cálculo simples para evaluar el coste del proyecto, ya que, por el momento los cálculos no son suficientes para el pago de personal y demás costos que conlleva el desarrollo del proyecto de software.')";
            $guardar5 = mysqli_query($con,$riesgo5); 
        } if(($sumaPresupuesto == $presupuesto)){
            $riesgos5 = "INSERT INTO riesgosproyectos (Correo, id_empresa, id_proyecto, riesgo , impacto, planMitigacion)
            Values('$Correo','$idEmpresa','$idProyecto','Presupuesto poco realista','Medio','Cuando no se cuenta con suficientes recursos económicos para la realización del proyecto, esto conlleva el retraso de la entrega de este. Es por lo cual, que es necesario que el Gerente de proyectos, cuente con herramientas tecnológicas, métricas o hojas de cálculo simples para evaluar el coste del proyecto, ya que, por el momento los cálculos son muy precisos y no da oportunidad a errores o a gastos inesperados.')";
            $guardaar5 = mysqli_query($con,$riesgos5); 
        }
        $tiempoParaAnalisis = $tiempocliente3 * 0.2;
        $tiempoParaDesarrollo = $tiempocliente3 * 0.4;
        $contador2 = 0;
        if(($tiempoanalisis3 < $tiempoParaAnalisis) && ($tiempodesarrollo3 < $tiempoParaDesarrollo)){
            $riesgo6 = "INSERT INTO riesgosproyectos (Correo, id_empresa, id_proyecto, riesgo , impacto, planMitigacion)
            Values('$Correo','$idEmpresa','$idProyecto','Calendario poco realista','Alto','Para determinar el tiempo de entrega del proyecto es muy importante establecer unos plazos razonables, realistas, medibles y pactados con el equipo de Proyecto y el cliente acerca de las actividades que son necesarias para completar el proyecto, además es necesario tener en cuenta el tiempo que se va a gastar en cada etapa del proyecto.')";
            $guardar6 = mysqli_query($con,$riesgo6); 
        }
        if($tiempoanalisis3 < $tiempoParaAnalisis){
            $contador2++;
        }if($tiempodesarrollo3 < $tiempoParaDesarrollo){
            $contador2++;
        }if($contador2 == 1){
            $riesgo6 = "INSERT INTO riesgosproyectos (Correo, id_empresa, id_proyecto, riesgo , impacto, planMitigacion)
            Values('$Correo','$idEmpresa','$idProyecto','Calendario poco realista','Medio','Para determinar el tiempo de entrega del proyecto es muy importante establecer unos plazos razonables, realistas, medibles y pactados con el equipo de Proyecto y el cliente acerca de las actividades que son necesarias para completar el proyecto, además es necesario tener en cuenta el tiempo que se va a gastar en cada etapa del proyecto.')";
            $guardar6 = mysqli_query($con,$riesgo6); 
        }
        $minimoReuniones = $reunion1 * 0.08;
        if(($disponibilidad == 'No') || ($intervencion == 'Inactiva') || ($reunion1 < $minimoReuniones)){
            $riesgo7 = "INSERT INTO riesgosproyectos (Correo, id_empresa, id_proyecto, riesgo , impacto, planMitigacion)
            Values('$Correo','$idEmpresa','$idProyecto','Ambigüedad de requerimientos','Medio','La asistencia e intervención del cliente durante las reuniones realizadas es de vital importancia, ya que, el producto final debe satisfacer las expectativas o requerimientos que el cliente desea. Por lo cual, si el cliente no interviene activamente o no tiene claro lo que quiere, es importante que el Gerente de proyecto en el transcurso de las reuniones le  realice múltiples preguntas al igual es necesario guiarlo en el tema que se esté llevando a cabo. Finalmente, es importante realizar un número representativo de reuniones durante el desarrollo del proyecto.')";
            $guardar7 = mysqli_query($con,$riesgo7); 
        }if(($disponibilidad == 'No') && ($intervencion == 'Inactiva') && ($reunion1 < $minimoReuniones)){
            $riesgo7 = "INSERT INTO riesgosproyectos (Correo, id_empresa, id_proyecto, riesgo , impacto, planMitigacion)
            Values('$Correo','$idEmpresa','$idProyecto','Ambigüedad de requerimientos','Alto','La asistencia e intervención del cliente durante las reuniones realizadas es de vital importancia, ya que, el producto final debe satisfacer las expectativas o requerimientos que el cliente desea. Por lo cual, si el cliente no interviene activamente o no tiene claro lo que quiere, es importante que el Gerente de proyecto en el transcurso de las reuniones le  realice múltiples preguntas al igual es necesario guiarlo en el tema que se esté llevando a cabo. Finalmente, es importante realizar un número representativo de reuniones durante el desarrollo del proyecto.')";
            $guardar7 = mysqli_query($con,$riesgo7); 
        }
        $contador3 = 0;
        if(($documentacion == 'No') && ($requisitos == 'Bajo (10% - 30%)') && ($almacenamiento == 'Papel')){
            $riesgo8 = "INSERT INTO riesgosproyectos (Correo, id_empresa, id_proyecto, riesgo , impacto, planMitigacion)
            Values('$Correo','$idEmpresa','$idProyecto','Falta de informe de los requerimientos','Alto','Llevar un registro de los requerimientos del cliente y del cambio de estos en el transcurso de desarrollo del proyecto, es de vital importancia para contar con un orden a la hora de desarrollar el trabajo e igualmente evitar bucles en las correcciones de errores. Es por tal razón, que es esencial dar importancia a la extracción de los requerimientos del proyecto, asimismo es de gran ayuda almacenarlos en herramientas tecnológicas para un mayor orden y seguridad de la documentación.')";
            $guardar8 = mysqli_query($con,$riesgo8); 
        }if($requisitos == 'Medio (31% - 60%)'){
            $contador3++;
        }if($documentacion == 'No'){
            $contador3++;
        }if($almacenamiento == 'Papel'){
            $contador3++;
        }if($contador3 <= 1){
            $riesgos8 = "INSERT INTO riesgosproyectos (Correo, id_empresa, id_proyecto, riesgo , impacto, planMitigacion)
            Values('$Correo','$idEmpresa','$idProyecto','Falta de informe de los requerimientos','Medio','Llevar un registro de los requerimientos del cliente y del cambio de estos en el transcurso de desarrollo del proyecto, es de vital importancia para contar con un orden a la hora de desarrollar el trabajo e igualmente evitar bucles en las correcciones de errores. Es por tal razón, que es esencial dar importancia a la extracción de los requerimientos del proyecto, asimismo es de gran ayuda almacenarlos en herramientas tecnológicas para un mayor orden y seguridad de la documentación.')";
            $guardaar8 = mysqli_query($con,$riesgos8); 
        }
        if(($seguimiento == 'No') || ($actualizar == "No") || ($actualizarDocumentos == 'No')){
            $riesgo9 = "INSERT INTO riesgosproyectos (Correo, id_empresa, id_proyecto, riesgo , impacto, planMitigacion)
            Values('$Correo','$idEmpresa','$idProyecto','Monitoreo y control inadecuados del proyecto','Alto','El no realizar un continuo seguimiento de los requerimientos genera un riesgo para el proyecto, por ende, es necesario realizar esto con una periodicidad regular y durante todas las etapas del proyecto, lo cual garantizará que cualquier irregularidad se detecte y corrija a tiempo, lo que permite reducir al mínimo los efectos perjudiciales para el proyecto. Igualmente, es necesario que se lleve a cabo una documentación de cada cambio que se vaya generando durante el proyecto, ya que, esto apoyará  la identificación de la solicitud realizada por el cliente. Esta documentación no debe ser ambigua y debe ser validada por las dos partes, el cliente y la empresa de desarrollo de software. Además, al estar documentados y actualizados los requerimientos permite trabajar siempre sobre la última versión de este, mejorando así la entrega final del proyecto.')";
            $guardar9 = mysqli_query($con,$riesgo9); 
        } if(($acceso == 'No') || ($desempeño == "No")){
            $riesgo10 = "INSERT INTO riesgosproyectos (Correo, id_empresa, id_proyecto, riesgo , impacto, planMitigacion)
            Values('$Correo','$idEmpresa','$idProyecto','Falta de datos necesarios para realizar un seguimiento objetivo de un proyecto','Alto','Para realizar correctamente el control o seguimiento del desarrollo del software, es importante que la información acerca de los cambios que se deben realizar en el desarrollo del proyecto sean accesibles para todos los integrantes del equipo de trabajo. E igualmente, es esencial que el Gerente del proyecto y/o líderes de grupo tengan un proceso determinado para evaluar el avance o desempeño en que se encuentra el proyecto en determinado momento.')";
            $guardar10 = mysqli_query($con,$riesgo10); 
        } if(($recursoHumano == 'Ambas') || ($recursoHumano == 'Se contrata personal externo')){
            $riesgo11 = "INSERT INTO riesgosproyectos (Correo, id_empresa, id_proyecto, riesgo , impacto, planMitigacion)
            Values('$Correo','$idEmpresa','$idProyecto','Desacuerdo entre miembros','Medio','El desacuerdo entre miembros se produce cuando la sinergia del equipo no es la más eficaz, ya que, hay personas que solo desean trabajar con gente parecida a ellos lo cual genera fuertes barreras para trabajar en conjunto con gente distinta o nueva, de igual manera existen personas que si se adaptan a cualquier ambiente. Es por tal razón, que es importante contratar personas que estén dispuestas a trabajar en equipo y se adapten a cualquier situación.')";
            $guardar10 = mysqli_query($con,$riesgo11); 
        }
        echo'<script type="text/javascript">
        alert("Proyecto Guardado con éxito!!");
        window.location.href="AreaPersonal.php";
        </script>';
    } 
?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
    <!-- <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> -->
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="EstilosCrearProyectos.css">

    <title>Prueba</title>
    <script type="text/javascript">
         function myFunction() {
                var valor1 = 0;
                var valor2 = 0;
                var valor3 = 0;
                var valor4 = 0;
                var valortotal = parseInt(document.getElementById("personasDelProyecto").value,10);
                var valor1 = parseInt(document.getElementById("selpersonas1").value,10);
                var valor2 = parseInt(document.getElementById("selpersonas2").value,10);
                var valor3 = parseInt(document.getElementById("selpersonas3").value,10);
                var valor4 = parseInt(document.getElementById("selpersonas4").value,10);
                var suma = valor1 + valor2 + valor3 + valor4;
                console.log(suma);
                if(suma > valortotal){
                    alert ("El número de personas en los cargos NO concuerda con el número de personas ingresadas!");        
                    document.getElementById("personasDelProyecto").focus();
                }
            }
            function dias(){
                var dias1 =  parseInt(document.getElementById("tiempoClienteDias").value,10);
                var dias2 =  parseInt(document.getElementById("tiempoReuniones").value,10);
                if(dias2 > dias1){
                    /*alert ("El número de reuniones es MAYOR al número de días para la entrega del proyecto"); */   
                    var w = window.open('','','width=300,height=100,left=500, top=200')
                    w.document.write('El número de reuniones es MAYOR al número de días para la entrega del proyecto.  Solo tienes '+ dias1 + ' días para la entrega del proyecto')
                    w.focus()
                    setTimeout(function() {w.close();}, 3800); 
                    document.getElementById("tiempoReuniones").focus();
                    }
            }
    </script>
    </head>
    <body>
    <nav class="navbar navbar-light bg-light" id="barraNavegacion" >
        <a class="navbar-brand" id="imagenLogo"  href="AreaPersonal.php"> <img src="imagensinfondo.png" alt="" srcset="" id="imagenLogo1"></a>
        <a class="navbar-brand" id="logo" href="AreaPersonal.php"> Detección de los Riesgos <br>
        <p id="subtitulo">En las etapas de pre análisis y análisis</p></a>
        <form class="form-inline" id="cajitaboton">
            <button class="btn btn-secondary my-2 my-sm-0" type="submit"> <a href="index.php" id="linkInicio">Cerrar Sesión</a></button>
        </form>
    </nav>
    <div style="height: 30px;"></div>
    <form action="CrearProyectos.php" method="POST" id="FormatoCrearProyectos" name="FormatoCrearProyectos">
        <?php 
         $sqlEmpresa = "SELECT * FROM empresa WHERE ID='$idEmpresa'";
         //$resultadoEmpresa = mysqli_query($con,$sqlEmpresa);
         $resultado = $con->query($sqlEmpresa);
         if($resultado ->num_rows > 0){
             while($row = $resultado->fetch_assoc()){
                 echo '<label for="" id="labelEmpresaSeleccionada"> <strong>EMPRESA:</strong> </label> <label id="empresa">'.$row['NombreEmpresa'].'</label>';
             }
         }
        ?>
        <br><br> <br>
        <div class="form-group">
            <label for="exampleFormControlInput1">Nombre Del proyecto</label>
            <input type="text" class="form-control" id="proyecto" name="proyecto" placeholder="Ingresa aquí el nombre de tu proyecto" maxlength="150" Required>
            <div class="valid-feedback">¡Ok válido!</div>
            <div class="invalid-feedback">Complete el campo</div>
        </div>
        <div class="form-group">
            <label for="exampleFormControlTextarea1">Descripción del proyecto</label>
            <textarea class="form-control" id="descripcionProyecto" name="descripcionProyecto" rows="3" maxlength="535" Required></textarea>
            <div class="valid-feedback">¡Ok válido!</div>
            <div class="invalid-feedback">Complete el campo</div>
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect1">¿Para este proyecto se utilizará recurso humano de la empresa o se contratará personal nuevo?</label>
            <select class="form-control" id="recursoHumano" name="recursoHumano" Required>
            <option value="Recurso humano existente">Recurso humano existente</option>
            <option value="Se contrata personal externo">Se contrata personal externo</option>
            <option value="Ambas">Ambas</option>
            </select>
        </div>
        <label for="" id="titulos"> <strong>1. CARACERISTICAS TÉCNICAS DEL PROYECTO</strong> </label>  <br>
        <div class="form-group">
            <label for="exampleFormControlInput1">¿Qué tecnologías se utilizaran en el proyecto?</label> <br>
            <label for=""> <strong>1.1. Tecnologías de la empresa</strong> </label>  <br>
            <table class="table table-bordered" id="tablaLenguajes">
            <thead>
                <tr>
                    <th scope="col">Tecnología</th>
                    <th scope="col">¿La utilizará?</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    //consulta a la base de datos
                    $sql = "SELECT * FROM lenguajes
                            WHERE id_empresa='$idEmpresa'
                            ORDER BY id_empresa";
                    $con = obtener_conexion();
                    $resultado = mysqli_query($con,$sql);

                    while($filas=mysqli_fetch_array($resultado)){ //mientras halla datos en la variable resultados 
                        ?>
                        <tr>
                            <td><?php echo $filas['Lenguajes']?></td>
                            <td>
                            <label><input type="checkbox" name="check_lista[]" value="<?php echo $filas['Lenguajes']?>"></label>

                            </td>
                        </tr>
                <?php }?> 
            </tbody>
        </table>
        <label for=""> <strong>1.2. Agregar tecnologías nuevas</strong> </label>  <br>
        <input type="button" class="btn btn-secondary" name="botonAgregarLenguaje" value="Agregar Tecnología" id="botonAgregarLenguaje">

        <table class="table table-bordered" id="tablaNuevosLenguajes">
            <thead>
                <tr>
                    <th scope="col">Tecnología </th>
                </tr>
            </thead>
            <tbody>
                        <tr>
                        </tr>
            </tbody>
        </table>
        </div>
        <label for="" id=""> <strong>Descripión del tiempo del proyecto</strong> </label>  <br>
        <div class="form-group">
            <label for="exampleFormControlInput1">¿Tiempo de entrega del proyecto estipula con el cliente?</label> <br>
            <label for="" id="labelDias">Número Días</label> <input type="number" class="form-control" id="tiempoClienteDias" name="tiempoClienteDias"  value=0   placeholder="DD" Required>
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect1">¿Cuánto tiempo se tiene estimado para las tareas de análisis del proyecto (Preanálisis, Análisis)?</label> <br>
            <label for="" id="labelDias"> Número Días</label> <input type="number" class="form-control" id="tiempoAnalisisDias" name="tiempoAnalisisDias"  value=0 placeholder="DD" Required>
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect1">¿Cuánto tiempo se tiene estimado para las tareas técnicas del proyecto (Desarrollo, Pruebas)?</label> <br>
            <label for="" id="labelDias"> Número Días</label> <input type="number" class="form-control" id="tiempoDesarrolloDias" name="tiempoDesarrolloDias" value=0  placeholder="DD" Required>
        </div>
        <label for="" id="titulos"> <strong>2. CARACERISTICAS DEL CLIENTE</strong> </label>  <br>
        <div class="form-group">
            <!-- 6 -->
            <label for="exampleFormControlSelect1">¿Cuánto conocimiento tiene el cliente acerca de las tecnologías a utilizar en el proyecto?</label>
            <select class="form-control" id="conocimientoCliente" name="conocimientoCliente" Required>
            <option value="Nulo ( 0% )">Nulo ( 0% )</option>
            <option value="Bajo ( 10% - 30% )">Bajo ( 10% - 30% )</option>
            <option value="Medio ( 31% - 60% )">Medio ( 31% - 60% )</option>
            <option value="Alto ( 61% - 100% )">Alto ( 61% - 100% )</option>
            </select>
        </div>
        <div class="form-group">
            <!-- 7 -->
            <label for="exampleFormControlSelect1">Con respecto a los requerimientos del proyecto, ¿Cuál es el nivel de claridad que tiene el cliente?</label>
            <select class="form-control" id="claridadCliente" name="claridadCliente" Required>
            <option value="Bajo (10% - 30%)">Bajo (10% - 30%)</option>
            <option value="Medio (31% - 60%)">Medio (31% - 60%)</option>
            <option value="Alto (61% - 100%)">Alto (61% - 100%)</option>
            </select>
        </div>  
        <div class="form-group">
            <label for="exampleFormControlInput1">¿El cliente cuenta con disponibilidad de tiempo para asistir a las reuniones acerca del proyecto?</label> <br>
            <select class="form-control" id="disponibilidadCliente" name="disponibilidadCliente" Required>
            <option value="Si">Sí</option>
            <option value="No">No</option>
            </select>
        </div>
        <div class="form-group">
            <label for="exampleFormControlInput1">¿Como interviene el cliente durante las reuniones del proyecto?</label> <br>
            <select class="form-control" id="intervencionCliente" name="intervencionCliente" Required>
            <option value="Activamente">Activamente</option>
            <option value="Medianamente Activo">Medianamente Activo</option>
            <option value="Inactiva">Inactivo</option>
            </select>
        </div>
        <label for=""> <strong>Frecuencia de reuniones</strong> </label>  <br>
        <label for="exampleFormControlInput1"> <strong> Periodicidad de las reuniones </strong></label> <br>
        <select class="form-control" id="CategoriaReuniones" name="CategoriaReuniones" Required>
            <option value="Diariamente">Diariamente</option>
            <option value="Semanalmente">Semanalmente</option>
            <option value="Mensualmente">Mensualmente</option>
        </select>
        <input type="text" class="form-control" id="tiempoReuniones" name="tiempoReuniones" onblur="dias()" placeholder="Número de reuniones con el cliente" Required> <br><br>

        <label for="" id="titulos"> <strong>3. CARACERISTICAS DEL EQUIPO DE TRABAJO</strong> </label>  <br>
        <div class="form-group">
            <label for="exampleFormControlTextarea1">¿Cuántas personas en total participarán en el proyecto?</label>
            <input type="number" class="form-control" id="personasDelProyecto" name="personasDelProyecto" placeholder="Cuantas personas hay en tu proyecto" Required> <br>
            <table class="table table-striped" id="tablaLenguajes">
                <tbody>
                    <tr>
                    <th>Cargo</th>
                    <th>Cantidad de personas</th>
                    <th>Salario Asignado por persona</th>
                    <td><input type="hidden"></td>
                    </tr>
                    <tr>
                    <th scope="row">
                    <div class="form-check">
                        <input type="hidden" id="hddnombrecargo1" name="hddnombrecargo1" value="Gerente">
                        <label class="form-check-label" for="defaultCheck1">
                        Gerente de Proyecto
                        </label>
                    </div>
                    </th>
                    <td>
                    <div class="form-group">
                        <input type="number" class="form-control" name="selpersonas1" id="selpersonas1" placeholder="Número de personas" value=0 onblur="myFunction()" require>
                    </div>
                    </td>
                    <td>
                    <div class="form-group">
                        <input type="number" class="form-control" name="selsalario1" id="selsalario1" placeholder="Salario Por Persona" require>
                    </div>
                    </td>
                    </tr>
                    <th scope="row">
                    <div class="form-check">
                        <input type="hidden" id="hddnombrecargo2" name="hddnombrecargo2" value="Análistas">
                        <label class="form-check-label" for="defaultCheck1">
                        Análistas Funcionales
                        </label>
                    </div>
                    </th>
                    <td>
                    <div class="form-group">
                        <input type="number" class="form-control" name="selpersonas2" id="selpersonas2" placeholder="Número de personas" value=0 onblur="myFunction()" require>
                    </div>
                    </td>
                    <td>
                    <div class="form-group">
                        <input type="number" class="form-control" name="selsalario2" id="selsalario2" placeholder="Salario Por Persona" require>
                    </div>
                    </td>
                    </tr>
                    <tr>
                    <th scope="row">
                    <div class="form-check">
                        <input type="hidden" id="hddnombrecargo3" name="hddnombrecargo3" value="Desarrolladores">
                        <label class="form-check-label" for="defaultCheck1">
                        Desarrolladores
                        </label>
                    </div>
                    </th>
                    <td>
                    <div class="form-group">
                        <input type="number" class="form-control" name="selpersonas3" id="selpersonas3" placeholder="Número de personas" value=0 onblur="myFunction()" require>
                    </div>
                    </td>
                    <td>
                    <div class="form-group">
                        <input type="number" class="form-control" name="selsalario3" id="selsalario3" placeholder="Salario Por Persona" require>
                    </div>
                    </td>
                    </tr>
                    <tr>
                    <th scope="row">
                    <div class="form-check">
                        <input type="hidden" id="hddnombrecargo4" name="hddnombrecargo4" value="Pruebas">
                        <label class="form-check-label" for="defaultCheck1">
                        Pruebas
                        </label>
                    </div>
                    </th>
                    <td>
                    <div class="form-group">
                        <input type="number" class="form-control" name="selpersonas4" id="selpersonas4" value=0 onblur="myFunction()" placeholder="Número de personas"  require>
                    </div>
                    </td>
                    <td>
                    <div class="form-group">
                        <input type="number" class="form-control" name="selsalario4" id="selsalario4" placeholder="Salario Por Persona" require>
                    </div>
                    </td>
                    </tr>
                    <tr>       
                </tbody>
            </table>
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect1">Según su experiencia en la dirección de proyectos ¿Considera que el personal asignado es suficiente para entregar el proyecto en el tiempo establecido?</label>
            <select class="form-control" id="suficientePersonalTiempo" name="suficientePersonalTiempo" Required>
            <option value="Si">Sí</option>
            <option value="No">No</option>
            </select>
        </div>
        <div class="form-group">
            <label for="exampleFormControlTextarea1">¿Qué conocimientos tiene el equipo con la tecnología a utilizar en el proyecto?
                <strong>(escala del 1 a 5, donde 1 es novato y 5 experto)</strong></label>
            <select class="form-control" id="conocimientoEquipo" name="conocimientoEquipo" Required>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            </select>
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect1">¿Si el personal no cuenta con conocimientos plenos de la tecnología y lenguaje a trabajar en el proyecto, se harán capacitaciones para entender mucho más estas herramientas?</label>
            <select class="form-control" id="capacitacionesPersonal" name="capacitacionesPersonal" Required>
            <option value="Si">Sí</option>
            <option value="No">No</option>
            </select>
        </div>
        <div class="form-group">
            <label for="exampleFormControlTextarea1">¿Qué conocimiento tiene usted como director de proyecto con la tecnología a utilizar en el proyecto?
                <strong>(escala del 1 a 5, donde 1 es novato y 5 experto)</strong></label>
            <select class="form-control" id="conocimientoDirector" name="conocimientoDirector" Required>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            </select>
        </div>
        <label for="" id="titulos"> <strong>4. CARACERISTICAS DE GESTIÓN DEL PROYECTO</strong> </label>  <br>
        <label for="" id=""> <strong>4.1. PRESUPUESTO</strong> </label>  <br>
        <div class="form-group">
            <label for="exampleFormControlInput1">¿Cuánto presupuesto ha sido asignado para la realización del proyecto?</label>
            <input type="text" class="form-control" id="presupuestoProyecto" name="presupuestoProyecto" placeholder="Presupuesto Total Proyecto" Required>
        </div>
        <div class="form-group">
            <label for="exampleFormControlInput1">¿Cuánto dinero del presupuesto ha sido destinado al pago de personal?</label>
            <input type="text" class="form-control" id="presupuestoPagoPersonal" name="presupuestoPagoPersonal" placeholder="Pago de salarios del Personal" Required>
        </div>
        <div class="form-group">
            <label for="exampleFormControlInput1">¿Qué dinero del presupuesto ha sido destinado para el pago de los gastos de estructura del proyecto, como coste de energía, agua, alquiler del local, ordenadores, etc.? </label>
            <input type="text" class="form-control" id="presupuestoGastos" name="presupuestoGastos" placeholder="Pago para pago de gastos de estructura del proyecto" Required>
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect1">¿Cuánto dinero del presupuesto ha sido destinado para los costos adicionales para los recursos de hardware, infraestructura o similares?</label>
            <input type="text" class="form-control" id="CostoTecnologia" name="CostoTecnologia" placeholder="Costo del proveedor de tecnología " >
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect1">Según su experiencia en la dirección de proyectos ¿Considera que el personal asignado es suficiente para entregar el proyecto en el presupuesto establecido?</label>
            <select class="form-control" id="suficientePersonalPresupuesto" name="suficientePersonalPresupuesto" Required>
            <option value="Si">Sí</option>
            <option value="No">No</option>
            </select>
        </div>
        <label for=""> <strong>4.2. DOCUMENTACIÓN</strong> </label>  <br>
        <div class="form-group">
            <label for="exampleFormControlSelect1">¿Qué importancia le da el cliente a la tarea de análisis y extracción de los requerimientos?</label>
            <select class="form-control" id="importanciaRequisitos" name="importanciaRequisitos" Required>
            <option value="Bajo (10% - 30%)">Bajo (10% - 30%)</option>
            <option value="Medio (31% - 60%)">Medio (31% - 60%)</option>
            <option value="Alto (61% - 100%)">Alto (61% - 100%)</option>
            </select>
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect1">¿Se tiene documentación del cambio continuo de los requerimientos dados por el cliente?</label>
            <select class="form-control" id="documentacion" name="documentacion" Required>
            <option value="Si">Sí</option>
            <option value="No">No</option>
            </select>
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect1">¿Las solicitudes del cambio de requerimientos por parte del cliente se documentan?</label>
            <select class="form-control" id="actualizarDocumentacion" name="actualizarDocumentacion" Required>
            <option value="Si">Sí</option>
            <option value="No">No</option>
            </select>
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect1">¿Donde se almacenan la documentación de los requerimientos?</label>
            <select class="form-control" id="AlmacenamientoRequerimientos" name="AlmacenamientoRequerimientos" Required>
            <option value="Papel">Papel</option>
            <option value="Herramienta Tecnologíca">Herramientas Tecnologícas</option>
            <option value="Ambas">Ambas</option>
            </select>
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect1">¿Los encargados del proyecto realizan un continuo seguimiento de los requerimientos?</label>
            <select class="form-control" id="seguimientoObjetivos" name="seguimientoObjetivos" Required>
            <option value="Si">Sí</option>
            <option value="No">No</option>
            </select>
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect1">¿Se actualiza la documentación de los requerimientos según los cambios realizados durante el desarrollo del proyecto?</label>
            <select class="form-control" id="actualizarObjetivos" name="actualizarObjetivos" Required>
            <option value="Si">Sí</option>
            <option value="No">No</option>
            </select>
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect1">¿Los encargados del proyecto proveen el acceso y uso de la información para controlar los cambios que se deben realizar durante el desarrollo?</label>
            <select class="form-control" id="accesoInformacion" name="accesoInformacion" Required>
            <option value="Si">Sí</option>
            <option value="No">No</option>
            </select>
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect1">¿Los encargados del proyecto cuentan con procesos para realizar el debido seguimiento, medición, análisis y evaluación del desempeño del proyecto?</label>
            <select class="form-control" id="evaluacionDesempeño" name="evaluacionDesempeño" Required>
            <option value="Si">Sí</option>
            <option value="No">No</option>
            </select>
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect1">¿Se usan herramientas tecnológicas como Git o TortoiseSVN para el control de versiones del código?</label>
            <select class="form-control" id="versionarCodigo" name="versionarCodigo" Required>
            <option value="Si">Sí</option>
            <option value="No">No</option>
            </select>
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect1">¿Se usan herramientas tecnológicas de apoyo a la gestión de proyectos como Jira?</label>
            <select class="form-control" id="herramientaGestion" name="herramientaGestion" Required>
            <option value="Si">Sí</option>
            <option value="No">No</option>
            </select>
        </div>

        <input type="hidden" id="idEmpresa" name="idEmpresa" value="<?= $idEmpresa ?>" />
        <input type="hidden" id="hddcantnuevos" name="hddcantnuevos" value="0" />
        <!-- <input type="button" class="btn btn-primary" name="calcularRiesgos" value="Detectar Riesgos" id="calcularRiesgos"> -->
        <input type="submit"  class="btn btn-primary" name="calcularRiesgos" value="Guardar Proyecto" id="calcularRiesgos">    
    </form>

    <div style="height: 50px;"></div>
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

<script type="text/javascript">
console.log("entró");
var g_cont=0;
document.write(g_cont);
$("#calcularRiesgos").click(function() {
$("#hddcantnuevos").val(g_cont);
                var valor1 = 0;
                var valor2 = 0;
                var valor3 = 0;
                var valor4 = 0;
                var valortotal = parseInt(document.getElementById("personasDelProyecto").value,10);
                var valor1 = parseInt(document.getElementById("selpersonas1").value,10);
                var valor2 = parseInt(document.getElementById("selpersonas2").value,10);
                var valor3 = parseInt(document.getElementById("selpersonas3").value,10);
                var valor4 = parseInt(document.getElementById("selpersonas4").value,10);
                var suma = valor1 + valor2 + valor3 + valor4;
                if(suma > valortotal){
                    alert ("El número de personas en los cargos NO concuerda con el número de personas ingresadas!");        
                    document.getElementById("personasDelProyecto").focus();
                }else{
                    console.log("enviando");
                    $("#FormatoCrearProyectos").submit();
                }});

$(document).ready(function(){
  $('#botonAgregarLenguaje').click(function(){
    agregar();
  });
});
function agregar(){
  var fila =
    '<tr>' +
      '<td>' +
        '<input class="form-control" type="text" name="lenguaje' + g_cont + '" id="lenguaje' + g_cont + '" placeholder="Ingresa la tecnología" maxlength="150">' +
      '</td>' +
    '</tr>';
    g_cont++;
  $('#tablaNuevosLenguajes').append(fila);
  
}
</script>
</body>
</html>
