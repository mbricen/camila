<?php
    @session_start();
   include("db/conexion.php");

   $con = obtener_conexion();
   $correo = $_SESSION["correo"];
   $id = $_GET['id'];
   
    if(isset($_GET['id'])){
        $id = $_GET['id'];
        $sql = "SELECT * FROM empresa WHERE id = $id";
        $sql2 = "SELECT * FROM lenguajes WHERE id_empresa = $id";
        $sql3 = "SELECT * FROM servicios WHERE id_empresa = $id";
        $resultado = mysqli_query($con,$sql);
        if(mysqli_num_rows($resultado)==1){
            $fila = mysqli_fetch_array($resultado);
            $mensaje1 = $fila['NombreEmpresa'];
            $mensaje2 = $fila['Empleados'];
            $mensaje3 = $fila['Años_empresa'];
            $mensaje4 = $fila['Capacitaciones'];
        }
    }
    if(isset($_POST['salida'])){
        header("Location: AreaPersonal.php");
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="StylesVerEmpresa.css">

    <!-- Font awesome 5 (iconos) -->
    <script src="https://kit.fontawesome.com/4a20e1c69f.js"></script>

    <title>Prueba</title>
</head>
<body>
    <nav class="navbar navbar-light bg-light" id="barraNavegacion" >
        <a class="navbar-brand" id="imagenLogo1"  href="AreaPersonal.php"> <img src="imagensinfondo.png" alt="" srcset="" id="imagenLogo1"></a>
        <a class="navbar-brand" id="logo" href="AreaPersonal.php"> Detección de los Riesgos <br>
        <p id="subtitulo">En las etapas de pre análisis y análisis</p></a>
        <form class="form-inline" id="cajitaboton">
            <button class="btn btn-secondary my-2 my-sm-0" type="submit"> <a href="index.php" id="linkInicio">Cerrar Sesión</a></button>
        </form>
    </nav>
    <div class="card"></div>
    <div class="card-body">

    </div>
    <form id="CaracteristicasEmpresa" action="verEmpresa.php" method="POST">
        <div class="form-group">
             <label for="formGroupExampleInput"><strong> Nombre de la Empresa</strong></label> <br>
             <label for="" class="form-control"><?php echo $mensaje1;?></label>
        </div>
        <div class="form-group">
             <label for="formGroupExampleInput"><strong>Servicios que ofrece la empresa</strong></label> <br>
              <?php
                    //consulta a la base de datos
                    $sql1 = "SELECT * FROM servicios
                            WHERE id_empresa='$id'";
                    $con = obtener_conexion();
                    $resultado = mysqli_query($con,$sql1);

                    while($filas=mysqli_fetch_array($resultado)){ //mientras halla datos en la variable resultados 
                        ?>
                        <ul id="listaLenguajes" name="listaLenguajes" class="list-group"> 
                            <li class="list-group-item">
                                <td><?php echo $filas['Servicio']?></td>
                            </li>             
                        </ul>
                <?php }?> 
        </div>
        <div class="form-group">
             <label for="formGroupExampleInput"><strong>¿Cuántos años lleva en el mercado la empresa?</strong></label> <br>
             <label for="" class="form-control"><?php echo $mensaje3;?></label>
        </div>
        <div class="form-group">
             <label for="formGroupExampleInput"> <strong>¿Cuántas personas conforman el equipo de trabajo?</strong></label> <br>
             <label for="" class="form-control"><?php echo $mensaje2;?></label>
        </div>
        <div class="form-group">
             <label for="formGroupExampleInput"> <strong>¿La empresa cuenta con un plan de formación tecnológica para sus empleados?</strong></label> <br>
             <label for="" class="form-control"><?php echo $mensaje4;?></label>
        </div>
        <div class="form-group">
             <label for="formGroupExampleInput"> <strong>¿Con qué tecnologías trabaja la empresa y cuantos años lleva utilizandolas?</strong></label> <br>
             <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">Tecnología</th>
                        <th scope="col">Años de Experiencia</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        //consulta a la base de datos
                        $sql = "SELECT * FROM lenguajes
                                WHERE  Id_empresa='$id'";
                        $con = obtener_conexion();
                        $resultado = mysqli_query($con,$sql);

                        while($filas=mysqli_fetch_array($resultado)){ //mientras halla datos en la variable resultados 
                            ?>
                            <tr>
                                <td><?php echo $filas['Lenguajes']?></td>
                                <td><?php echo $filas['Puntuacion']?></td>
                            </tr>
                    <?php }?> 
                </tbody>
            </table>
              
        </div>
        <input type="submit" class="btn btn-primary" name="salida" id="salida" value="Página Inicio">
    </form>
    <div style="height: 75px;"></div>


  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>    
</body>
</html>