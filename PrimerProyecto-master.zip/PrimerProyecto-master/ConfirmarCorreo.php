<?php
session_start();

include_once("db/conexion.php");

$correo = $_POST['correo'];
$clave = $_POST['clave'];

//conectar base de datos 
$con = obtener_conexion();

//validar el correo y clave 
$sql = "SELECT * FROM usuarios WHERE correo = '$correo' AND clave = '$clave' ";
$resultado = mysqli_query($con,$sql); 
echo $reultado;
$filas = mysqli_num_rows($resultado); //devuelve el número de filas con el resultado de la consulta
echo '$filas';
if($filas>0){
    $_SESSION["correo"] = $correo;
    setcookie("cookie",$correo);
    header("Location:AreaPersonal.php");
    
}else{
    echo '<div class="msj">Datos erroneos </div>';
}
?>
