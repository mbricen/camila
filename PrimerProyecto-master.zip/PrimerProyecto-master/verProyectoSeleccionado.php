<?php
    @session_start();
   include("db/conexion.php");

   $con = obtener_conexion();
   $correo = $_SESSION["correo"];
   $id = $_GET['id'];
   
    if(isset($_GET['id'])){
        $id = $_GET['id'];
        $sql = "SELECT * FROM proyecto WHERE ID = $id";
        $sql2 = "SELECT * FROM lenguajes WHERE id_empresa = $id";
        $sql3 = "SELECT * FROM servicios WHERE id_empresa= $id";
        $resultado = mysqli_query($con,$sql);
        if(mysqli_num_rows($resultado) == 1){
            $fila = mysqli_fetch_array($resultado);
            $mensaje1 = $fila['Nombre'];
            $mensaje2 = $fila['Descripcion'];
            $mensaje3 = $fila['RecursoHumano'];
            $mensaje6 = $fila['TiempoClienteDias'];
            $mensaje9 = $fila['TiempoAnalisisDias'];
            $mensaje12 = $fila['TiempoDesarrolloDias'];
            $mensaje13 = $fila['ConocimientoCliente'];
            $mensaje14 = $fila['ClaridadCliente'];
            $mensaje15 = $fila['DisponibilidadCliente'];
            $mensaje16 = $fila['IntervencionCliente'];
            $mensaje17 = $fila['Reuniones'];
            $mensaje18 = $fila['CategoriaReuniones'];
            $mensaje19 = $fila['Personas'];
            $mensaje20 = $fila['SuficientePersonalTiempo'];
            $mensaje21 = $fila['ConocimientoEquipo'];
            $mensaje22 = $fila['Capacitaciones'];
            $mensaje23 = $fila['ConocimientoDirector'];
            $mensaje24 = $fila['Presupuesto'];
            $mensaje25 = $fila['PresupuestoPersonal'];
            $mensaje26 = $fila['PresupuestoGastos'];
            $mensaje27 = $fila['CostoTecnologia'];
            $mensaje28 = $fila['SuficientePersonalPresupuesto'];
            $mensaje29 = $fila['Requerimientos'];
            $mensaje30 = $fila['Documentacion'];
            $mensaje31 = $fila['ActualizarDocumentos'];
            $mensaje32 = $fila['AlmacenamientoDocumentacion'];
            $mensaje33 = $fila['Seguimiento'];
            $mensaje34 = $fila['ActualizarCambios'];
            $mensaje35 = $fila['AccesoInformacion'];
            $mensaje36 = $fila['EvaluacionDesempeño'];
            $mensaje37 = $fila['HerramientaVersiones'];
            $mensaje38 = $fila['HerramientaGestion'];
        }
    }
    if(isset($_POST['salida'])){
        header("Location: AreaPersonal.php");
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="EstilosProyectoSeleccionado.css">

    <!-- Font awesome 5 (iconos) -->
    <script src="https://kit.fontawesome.com/4a20e1c69f.js"></script>

    <title>Prueba</title>
</head>
<body>
    <nav class="navbar navbar-light bg-light" id="barraNavegacion" >
        <a class="navbar-brand" id="imagenLogo"  href="AreaPersonal.php"> <img src="imagensinfondo.png" alt="" srcset="" id="imagenLogo1"></a>
        <a class="navbar-brand" id="logo" href="AreaPersonal.php"> Detección de los Riesgos <br>
        <p id="subtitulo">En las etapas de pre análisis y análisis</p></a>
        <form class="form-inline" id="cajitaboton">
            <button class="btn btn-secondary my-2 my-sm-0" type="submit"> <a href="index.php" id="linkInicio">Cerrar Sesión</a></button>
        </form>
    </nav>
    <div class="card"></div>
    <div class="card-body">

    </div>
    <form id="CaracteristicasProyecto" action="verProyectoSeleccionado.php" method="POST">
        <div class="form-group">
             <label for="formGroupExampleInput">Nombre del proyecto</label> <br>
             <label for="" class="form-control"><?php echo $mensaje1; ?></label>
        </div>
        <div class="form-group">
             <label for="formGroupExampleInput">Descripción del proyecto</label> <br>
             <label for="" class="form-control"><?php echo $mensaje2; ?></label>
        </div>
        <div class="form-group">
             <label for="formGroupExampleInput">¿Para este proyecto se utilizará recurso humano de la empresa o se contratará personal nuevo?</label> <br>
             <label for="" class="form-control"><?php echo $mensaje3; ?></label>
        </div> 
        <label for="" id="titulos"> <strong>1. CARACERISTICAS TÉCNICAS DEL PROYECTO</strong> </label>  <br>
        <div class="form-group">
        <label for="exampleFormControlInput1">¿Qué tecnologías se utilizaran en el proyecto?</label> <br>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th scope="col">Tecnología</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    //consulta a la base de datos
                    $sql = "SELECT * FROM tecnologiasproyecto
                            WHERE  CorreoEmpresa='$correo' AND IdProyecto='$id'";
                    $con = obtener_conexion();
                    $resultado = mysqli_query($con,$sql);

                    while($filas=mysqli_fetch_array($resultado)){ //mientras halla datos en la variable resultados 
                        ?>
                        <tr>
                            <td><?php echo $filas['Tecnologia']?></td>
                        </tr>
                <?php }?> 
            </tbody>
        </table>
        </div>
        <label for="" id=""> <strong>Descripión del tiempo del proyecto</strong> </label>  <br>
        <div class="form-group">
            <label for="exampleFormControlInput1">¿Tiempo de entrega del proyecto estipula con el cliente?</label> <br>
            <label for="" id="labelDias" style="font-weight: bold;">Número Días</label> <?php echo("  "); echo $mensaje6; echo("  ");?>
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect1">¿Cuánto tiempo se tiene estimado para las tareas de análisis del proyecto (Preanálisis, Análisis)?</label> <br>
            <label for="" id="labelDias" style="font-weight: bold;"> Número Días</label> <?php echo("  "); echo $mensaje9; echo("  "); ?>
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect1">¿Cuánto tiempo se tiene estimado para las tareas técnicas del proyecto (Desarrollo, Pruebas)?</label> <br>
            <label for="" id="labelDias" style="font-weight: bold;"> Número Días</label><?php echo("  "); echo $mensaje12; echo("  ");?>
        </div>
        </div> 
        <label for="" id="titulos"> <strong>2. CARACERISTICAS DEL CLIENTE</strong> </label>  <br>
        <div class="form-group">
             <label for="formGroupExampleInput">¿Cuánto conocimiento tiene el cliente acerca de las tecnologías a utilizar en el proyecto?</label> <br>
             <label for="" class="form-control"><?php echo $mensaje13; ?></label>
        </div> 
        <div class="form-group">
             <label for="formGroupExampleInput">Con respecto a los requerimientos del proyecto, ¿Cuál es el nivel de claridad que tiene el cliente?</label> <br>
             <label for="" class="form-control"><?php echo $mensaje14; ?></label>
        </div> 
        <div class="form-group">
             <label for="formGroupExampleInput">¿El cliente cuenta con disponibilidad de tiempo para asistir a las reuniones acerca del proyecto?</label> <br>
             <label for="" class="form-control"><?php echo $mensaje15; ?></label>
        </div> 
        <div class="form-group">
             <label for="formGroupExampleInput">¿El cliente interviene en la planificación de las reuniones del proyecto?</label> <br>
             <label for="" class="form-control"><?php echo $mensaje16; ?></label>
        </div> 
        <label for=""> <strong>Frecuencia de reuniones</strong> </label>  <br>
        <?php echo("  "); echo("Número de reuniones: "); echo("  ");echo $mensaje17; echo("  ");?> <br>
        <?php echo("Peridiocidad de reuniones: "); echo("  ");echo $mensaje18; echo("  "); ?> <br><br>

        <label for="" id="titulos"> <strong>3. CARACERISTICAS DEL EQUIPO DE TRABAJO</strong> </label>  <br>
        <div class="form-group">
             <label for="formGroupExampleInput">¿Cuántas personas en total participarán en el proyecto?</label> <br>
             <label for="" class="form-control"><?php echo $mensaje19;?></label>
             <table class="table table-bordered">
            <thead>
                <tr>
                    <th scope="col">Cargo</th>
                    <th>Cantidad de personas</th>
                    <th>Salario Asignado por persona</th>
                </tr>
            </thead>
            <tbody>
            <?php
                    //consulta a la base de datos
                    $sql = "SELECT * FROM proyecto
                            WHERE  CorreoEmpresa='$correo' AND ID='$id'";
                    $con = obtener_conexion();
                    $resultado = mysqli_query($con,$sql);

                    while($filas=mysqli_fetch_array($resultado)){ //mientras halla datos en la variable resultados 
                        ?>
                        <tr>
                              <td>Gerente</td> 
                              <td><?php echo $filas['Gerentes']?></td>
                              <td><?php echo $filas['SueldoGerente']?></td>
                        </tr>
                        <tr>
                              <td>Análistas Funcionales</td> 
                              <td><?php echo $filas['Analistas']?></td>
                              <td><?php echo $filas['SueldoAnalista']?></td>
                        </tr>
                        <tr>
                              <td>Desarrolladores</td> 
                              <td><?php echo $filas['Desarrollador']?></td>
                              <td><?php echo $filas['SueldoDesarrollador']?></td>
                        </tr>
                        <tr>
                              <td>Pruebas</td> 
                              <td><?php echo $filas['Pruebas']?></td>
                              <td><?php echo $filas['SueldoPruebas']?></td>
                        </tr>
                <?php }?> 
            </tbody>
        </table>
        </div> 
        <div class="form-group">
             <label for="formGroupExampleInput">Según su experiencia en la dirección de proyectos ¿Considera que el personal asignado es suficiente para entregar el proyecto en el tiempo establecido?</label> <br>
             <label for="" class="form-control"><?php echo $mensaje20;?></label>
        </div> 
        <div class="form-group">
        <label for="exampleFormControlTextarea1">¿Qué conocimientos tiene el equipo con la tecnología a utilizar en el proyecto?
                <strong>(escala del 1 a 5, donde 1 es novato y 5 experto)</strong></label>
        <label for="" class="form-control"><?php echo $mensaje21; ?></label>
        </div> 
        <div class="form-group">
             <label for="formGroupExampleInput">¿Si el personal no cuenta con conocimientos plenos de la tecnología y lenguaje a trabajar en el proyecto, se harán capacitaciones para entender mucho más estas herramientas?</label> <br>
             <label for="" class="form-control"><?php echo $mensaje22; ?></label>
        </div> 
        <div class="form-group">
        <label for="exampleFormControlTextarea1">¿Qué conocimiento tiene usted como director de proyecto con la tecnología a utilizar en el proyecto? 
                <strong>(escala del 1 a 5, donde 1 es novato y 5 experto)</strong></label>
        <label for="" class="form-control"><?php echo $mensaje23; ?></label>
        </div>
        <label for="" id="titulos"> <strong>4. CARACERISTICAS DE GESTIÓN DEL PROYECTO</strong> </label>  <br>
        <label for="" id="titulos"> <strong>4.1. PRESUPUESTO</strong> </label>  <br>
        <div class="form-group">
             <label for="formGroupExampleInput">¿Cuánto presupuesto ha sido asignado para la realización del proyecto?</label> <br>
             <label for="" class="form-control"><?php echo $mensaje24; ?></label>
        </div> 
        <div class="form-group">
             <label for="formGroupExampleInput">Cuánto dinero del presupuesto ha sido destinado al pago de personal?</label> <br>
             <label for="" class="form-control"><?php echo $mensaje25; ?></label>
        </div> 
        <div class="form-group">
             <label for="formGroupExampleInput">¿Qué dinero del presupuesto ha sido destinado para el pago de los gastos de estructura del proyecto, como coste de energía, agua, alquiler del local, ordenadores, etc.?</label> <br>
             <label for="" class="form-control"><?php echo $mensaje26; ?></label>
        </div> 
        <div class="form-group">
             <label for="formGroupExampleInput">¿Cuánto dinero del presupuesto ha sido destinado para los costos adicionales para los recursos de hardware, infraestructura o similares?</label> <br>
             <label for="" class="form-control"><?php echo $mensaje27; ?> <br></label>
        </div> 
        <div class="form-group">
             <label for="formGroupExampleInput">Según su experiencia en la dirección de proyectos ¿Considera que el personal asignado es suficiente para entregar el proyecto en el presupuesto establecido?</label> <br>
             <label for="" class="form-control"><?php echo $mensaje28; ?> <br></label>
        </div> 
        <label for="" id="titulos"> <strong>4.2. DOCUMENTACIÓN</strong> </label>  <br>
        <div class="form-group">
             <label for="formGroupExampleInput">¿Qué importancia le da el cliente a la tarea de análisis y extracción de los requerimientos?</label> <br>
             <label for="" class="form-control"><?php echo $mensaje29; ?></label>
        </div>
        <div class="form-group">
             <label for="formGroupExampleInput">¿Se tiene documentación del cambio continuo de los requerimientos dados por el cliente?</label> <br>
             <label for="" class="form-control"><?php echo $mensaje30; ?></label>
        </div> 
        <div class="form-group">
             <label for="formGroupExampleInput">¿Las solicitudes del cambio de requerimientos por parte del cliente se documentan?</label> <br>
             <label for="" class="form-control"><?php echo $mensaje31; ?></label>
        </div>
        <div class="form-group">
             <label for="formGroupExampleInput">¿Donde se almacenan la documentación de los requerimientos?</label> <br>
             <label for="" class="form-control"><?php echo $mensaje32; ?></label>
        </div>
        <div class="form-group">
             <label for="formGroupExampleInput">¿Los encargados del proyecto realizan un continuo seguimiento de los requerimientos?</label> <br>
             <label for="" class="form-control"><?php echo $mensaje33; ?></label>
        </div>
        <div class="form-group">
             <label for="formGroupExampleInput">¿Se actualiza la documentación de los requerimientos según los cambios realizados durante el desarrollo del proyecto?</label> <br>
             <label for="" class="form-control"><?php echo $mensaje34; ?></label>
        </div>
        <div class="form-group">
             <label for="formGroupExampleInput">¿Los encargados del proyecto proveen el acceso y uso de la información para controlar los cambios que se deben realizar durante el desarrollo?</label> <br>
             <label for="" class="form-control"><?php echo $mensaje35; ?></label>
        </div>
        <div class="form-group">
             <label for="formGroupExampleInput">¿Los encargados del proyecto cuentan con procesos para realizar el debido seguimiento, medición, análisis y evaluación del desempeño del proyecto?</label> <br>
             <label for="" class="form-control"><?php echo $mensaje36; ?></label>
        </div>
        <div class="form-group">
             <label for="formGroupExampleInput">¿Se usan herramientas tecnológicas como Git o TortoiseSVN para el control de versiones del código?</label> <br>
             <label for="" class="form-control"><?php echo $mensaje37; ?></label>
        </div>
        <div class="form-group">
             <label for="formGroupExampleInput">¿Se usan herramientas tecnológicas de apoyo a la gestión de proyectos como Jira?</label> <br>
             <label for="" class="form-control"><?php echo $mensaje38; ?></label>
        </div>
        <input type="submit" class="btn btn-primary" name="salida" id="salida" value="Página Inicio">
    </form>
    <div style="height: 75px;"></div>


  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>    
</body>
</html>