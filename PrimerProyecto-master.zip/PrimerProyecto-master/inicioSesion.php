<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="StylesInicio.css">
    <title>Prueba</title>
</head>
<body>
    <nav class="navbar navbar-light bg-light" id="barraNavegacion" >
        <a class="navbar-brand" id="imagenLogo" href="index.php"> <img src="imagensinfondo.png" alt="" srcset="" id="imagenLogo1"></a>
        <a class="navbar-brand" id="logo" href="index.php"> Detección de los Riesgos <br>
        <p id="subtitulo">En las etapas de pre análisis y análisis</p></a>
        
    </nav>
    <div style="height: 30px;"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="card shadow-lg p-3 mb-5 bg-white">
                    <div class="card-header">Formulario de Inicio</div>
                    <div class="card-body">
                        <form id="form1" action="ConfirmarCorreo.php" method="POST" class="needs-validation" validate>
                            <div class="form-row">
                                <div class="col-md-6 mb-3">
                                    <label for="correo">Correo</label>
                                    <input type="email" name="correo" id="correo" class="form-control" placeholder="Ingrese Su Correo" required>
                                    <div class="valid-feedback">¡Ok válido!</div>
                                    <div class="invalid-feedback">Complete el campo</div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="clave">Contraseña</label>
                                    <input type="password" name="clave" id="clave" class="form-control" placeholder="Ingrese Su Contraseña" required>
                                    <div class="valid-feedback">¡Ok válido!</div>
                                    <div class="invalid-feedback">Complete el campo</div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary" id="botonEnviar">Enviar</button>
                        </form>
                    </div>
                </div>
               
            </div>
        </div>
    </div>

    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>