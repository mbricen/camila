<?php
    @session_start();

    //include("conexionArea.php");
    include_once("db/conexion.php");

    $correo = $_SESSION["correo"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="StylesAreaPersonal.css">

    <!-- Font awesome 5 (iconos) -->
    <script src="https://kit.fontawesome.com/4a20e1c69f.js"></script>

    <title>Prueba</title>
</head>
<body>
    <?php
        //include('conexionArea.php');
        include('Agregar.php');
        include('eliminar.php');
    ?>
    <nav class="navbar navbar-light bg-light" id="barraNavegacion" >
        <a class="navbar-brand" id="imagenLogo"  href="AreaPersonal.php"> <img src="imagensinfondo.png" alt="" srcset="" id="imagenLogo1"></a>
        <a class="navbar-brand" id="logo" href="AreaPersonal.php"> Detección de los Riesgos <br>
        <p id="subtitulo">En las etapas de pre análisis y análisis</p></a>
        <form class="form-inline" id="cajitaboton">
            <button class="btn btn-secondary my-2 my-sm-0" type="submit"> <a href="index.php" id="linkInicio">Cerrar Sesión</a></button>
        </form>
    </nav>
    
    <button type="submit" class="btn btn-danger" id="botonAgregar"> <a href="AgregarEmpresa.php"  id="linkInicio" >Agregar Empresa</a></button>
    <p id="nota">*El prototipo solo permite agregar una empresa</p>
    <div style="height:30px;"></div>

    <?php  if(isset($_SESSION['mensaje'])){ ?>
            <div class="alert alert-<?= $_SESSION['tipo_mensaje']; ?> alert-dismissible fade show" role="alert">
                <?= $_SESSION['mensaje']?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                 <span aria-hidden="true">&times;</span>
                </button>
            </div>
        
    <?php  } ?>
    <div>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th scope="col">Nombre Empresa</th>
                    <th scope="col">Equipo de Trabajo</th>
                    <th scope="col">Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    //consulta a la base de datos
                    $sql = "SELECT * FROM empresa
                            WHERE Correo='$correo'
                            ORDER BY ID";

                    $con = obtener_conexion();

                    $resultado = mysqli_query($con,$sql);
                    $contador = mysqli_num_rows($resultado);
                    if($contador>=1){?>
                        <script>
                            document.getElementById("botonAgregar").style.opacity = "0";
                        </script>
                <?php } 
                    
                    while($filas=mysqli_fetch_array($resultado)){ //mientras halla datos en la variable resultados 
                        ?>
                        <tr>
                            <td><?php echo $filas['NombreEmpresa']?></td>
                            <td><?php echo $filas['Empleados']?></td>
                            <td>
                                <a href="verEmpresa.php?id=<?php echo $filas['ID']?>" class="btn btn-secondary"> Ver Empresa
                                     <i class="fas fa-eye"></i> 
                                </a>
                                <a href="CrearProyectos.php?id=<?php echo $filas['ID']?>" class="btn btn-secondary"> Crear Proyectos
                                    <i class="fas fa-marker"></i>
                                </a>
                                <a href="VerProyectos.php?id=<?php echo $filas['ID']?>" class="btn btn-secondary"> Ver Proyectos
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="eliminar.php?id=<?php echo $filas['ID']?>" class="btn btn-danger"> Eliminar Empresa
                                    <i class="far fa-trash-alt"></i>
                                </a>
                            </td>
                        </tr>
                        <?php }?>                        
            </tbody>
        </table>
    </div>

    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>    
</body>
</html>