n<?php
    function obtener_conexion() {
        //conectar base de datos 
        /*$conexion = pg_connect("host=ec2-52-73-247-67.compute-1.amazonaws.com
        port=5432 
        dbname=dfbehudhjnjpgq 
        user=fqosfnlaajzchx
        password=9b512dc0fd60630edf30d93428c5763b97c698be10bfbf5a2960d1e451564e82");   
        /*$user = "fqosfnlaajzchx";
        $pass= "9b512dc0fd60630edf30d93428c5763b97c698be10bfbf5a2960d1e451564e82";
        $server = "ec2-52-73-247-67.compute-1.amazonaws.com";
        $db = "dfbehudhjnjpgq";
        $conexion = pg_connect("host=$server port=5432 dbname=$db user=$user password=$pass");
        $user = "root";
        $pass = "";
        $server = "localhost";
        $db = "proyecto";
        $conexion= mysqli_connect($server,$user,$pass) or die("Error al conectar a la BD".mysql_error()); //variable que contiene la conexión con la bd
        mysqli_select_db($conexion,$db); */
        $conexion = pg_pconnect("host=ec2-52-87-58-157.compute-1.amazonaws.com port=5432 dbname=d7dd7hbsh5ua98 user=rzlzqqdgpkxqws password=a52850654f31ed1fa076fdd7056901220fce37182b6bb8e98d70790bd2ba989a");
        return $conexion;
        /* $conn_string = "host=ec2-52-73-247-67.compute-1.amazonaws.com port=5432 dbname=dfbehudhjnjpgq user=fqosfnlaajzchx password=9b512dc0fd60630edf30d93428c5763b97c698be10bfbf5a2960d1e451564e82";
        $dbconn4 = pg_connect($conn_string);

        return $dbconn4; */

        /*$host = "ec2-52-73-247-67.compute-1.amazonaws.com";
        $user = "fqosfnlaajzchx";
        $password = "9b512dc0fd60630edf30d93428c5763b97c698be10bfbf5a2960d1e451564e82";
        $dbname = "dfbehudhjnjpgq";
        $port = "5432";
        try{
        $conexion = "pgsql:host=" . $host . ";port=" . $port . ";dbname=" . $dbname . ";user=" . $user . ";password=" . $password . "";
        
        $pdo = new PDO($conexion, $user, $password);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_NODE,PDO::FETCH_OBJ);
        $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
        $pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

        return $conexion;
        }
        catch (PDOException $e){
            echo 'Connection failed: '. $e->getMessage();
        }*/
    }
?>
