<?php
    @session_start();

    include_once("db/conexion.php");

    $con = obtener_conexion();
    $Correo = $_SESSION["correo"];
    
    if(isset($_GET['id'])){
        $id = $_GET['id'];
        $sql = "DELETE FROM empresa WHERE id = $id";
        $sql2 = "DELETE FROM lenguajes WHERE id_empresa = $id";
        $sql3 = "DELETE FROM servicios WHERE id_empresa = $id";
        $sql4 = "DELETE FROM proyecto WHERE id_empresa = $id";
        $sql5 = "DELETE FROM riesgosproyectos WHERE id_empresa = $id";
        $sql6 = "DELETE FROM tecnologiasproyecto WHERE idEmpresa = $id";
        $resultado = mysqli_query($con,$sql);
        $resultado2 = mysqli_query($con,$sql2);
        $resultado3 = mysqli_query($con,$sql3);
        $resultado4 = mysqli_query($con,$sql4);
        $resultado5 = mysqli_query($con,$sql5);
        $resultado6 = mysqli_query($con,$sql6);
        echo("listo");
        if((!$resultado) || (!$resultado2) || (!$resultado3) || (!$resultado4) || (!$resultado5) || (!$resultado5)){
            die("Query failed");
        } 
        $_SESSION['mensaje'] = 'Datos eliminados satisfactoriamente';
        $_SESSION['tipo_mensaje'] ='danger';
        header("Location: AreaPersonal.php");
    } 
  
?>