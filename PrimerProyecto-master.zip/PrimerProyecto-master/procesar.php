<?php 
include("db/conexion.php");

$con = obtener_conexion();

$Nombre = $_POST['nombre'];
$Apellido = $_POST['apellido'];
$Correo = $_POST['correo'];
$Clave = $_POST['clave'];

//confirmar clave y verificar correo 
$buscarCorreo = "SELECT * from usuarios WHERE correo='$Correo'";

//Realizamos la consulta y anadimos $con, ya que es la variable de conexion con la DB
    $resultado = $con->query($buscarCorreo);

    //Usaremos la funcion mysqli_num_rows en la consulta $resultado,
    //esta funcion nos regresa el numero de filas en el resultado
    $contador = mysqli_num_rows($resultado);

if($contador == 1){
    echo 'El correo ya existe intenta con otro';
}else{
    //sentencia sql para guardar datos
    $sql = "INSERT INTO usuarios (apellido, clave, correo, nombre) VALUES ('$Apellido','$Clave','$Correo','$Nombre')";
    //ejecutamos la sentencia sql
    $ejecutar = mysqli_query($con,$sql); 
    header('Location:AreaPersonal.php'); //redireccionar a al pagina inicio
    
}
?>
