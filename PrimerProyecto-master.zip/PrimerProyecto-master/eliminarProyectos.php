<?php
    @session_start();

    include_once("db/conexion.php");

    $con = obtener_conexion();
    $Correo = $_SESSION["correo"];
    $ID = $_GET['id'];

    if(isset($_GET['id'])){
        $ID = $_GET['id'];
        //$mysqli->query("DELETE FROM proyecto WHERE id_empresa = $id") or die($mysqli->error());
        $sql = "DELETE FROM proyecto WHERE id = $ID";
        $sql2 = "DELETE FROM tecnologiasproyecto WHERE IdProyecto = $ID";
        $sql3 = "DELETE FROM riesgosproyectos WHERE id_proyecto = $ID";
        $resultado = mysqli_query($con,$sql);
        $resultado2 = mysqli_query($con,$sql2);
        $resultado3 = mysqli_query($con,$sql3);
        echo("listo");
        if(!$resultado || !$resultado2 || !$resultado3){
            die("Query failed");
        }  
        $_SESSION['mensaje'] = 'Datos eliminados satisfactoriamente';
        $_SESSION['tipo_mensaje'] ='danger';
        header("Location: verProyectos.php");
    }    

?>