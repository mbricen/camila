<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="EstilosHome.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <title>Prueba</title>
</head>
<body>
   <!-- <div id="outpur"></div>
    <script>
        fetch("/api/all").then(function(response){
            console.log(response);
            return response.text();
        }).then(function(response){
            document.getElementById("output").textContent = response;
        });
    </script> -->
    <nav class="navbar navbar-light bg-light" id="barraNavegacion" >
        <a class="navbar-brand" id="imagenLogo"> <img src="imagensinfondo.png" alt="" srcset="" id="imagenLogo1"></a>
        <a class="navbar-brand" id="logo"> Detección de los Riesgos <br>
        <p id="subtitulo">En las etapas de pre análisis y análisis</p></a>
        <form class="form-inline">
            <button class="btn btn-secondary my-2 my-sm-0" type="submit" id="botonInicio"> <a href="inicioSesion.php" id="linkInicio">Iniciar Sesión</a></button>
        </form>
    </nav>
    <div style="height: 90px;"></div>
    <h1 class="animated bounce delay-0s" id="titulo">BIENVENIDOS</h1>
    <h2 id="primerParrafo">Esta herramienta te puede servir de apoyo en la detección de los riesgos que se pueden presentar durante las etapas de pre análisis y análisis 
        de tu proyecto. 
    </h2>
    <div style="height: 30px;"></div>
    <img src="ciclo de vida N.PNG" alt="" id="imagen2">
    <div style="height: 50px;"></div>
    <h3 id="segundoParrafo">Registrate y disfruta de este beneficio.</h3>
    <div style="height: 25px;"></div>
    <button class="btn btn-info my-2 my-sm-0" type="submit" id="botonFinal"> <a href="registrarse.php" id="linkCrear">Crear Cuenta</a></button>
    <div style="height: 75px;"></div>
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>
