const express = require("express");
const mysql = require("postgresql");

const app = express();

const PORT = process.env.PORT || 8080;

const connection = mysql.createConnection({
    host: "ec2-52-73-247-67.compute-1.amazonaws.com",
    port: "5432",
    user: "fqosfnlaajzchx",
    password: "9b512dc0fd60630edf30d93428c5763b97c698be10bfbf5a2960d1e451564e82",
    database: "dfbehudhjnjpgq"
});

app.use(express.json());
app.use(express.urlencoded({ extended: true}));
app.use(express.static("public"));

connection.connect(function(error){
    console.log("connected to bd");
    app.listen(PORT, function(){
        console.log("listening at port "+ PORT);
    });
});

app.get("/api/all", function(req, res){
    //res.send("proyecto");
  /*   connection.query("SELECT * FROM ??", "usuarios", function(error, result){
        //console.log(result);
        res.json(result);
    }); */
});


