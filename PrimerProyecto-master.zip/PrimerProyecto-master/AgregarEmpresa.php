<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="EstilosAgregarEmpresa.css">

    <title>Prueba</title>
</head>
<body> 
   <nav class="navbar navbar-light bg-light" id="barraNavegacion" >
        <a class="navbar-brand" id="imagenLogo" href="AreaPersonal.php"> <img src="imagensinfondo.png" alt="" srcset="" id="imagenLogo1"></a>
        <a class="navbar-brand" id="logo" href="AreaPersonal.php"> Detección de los Riesgos <br>
        <p id="subtitulo">En las etapas de pre análisis y análisis</p></a>
        <form class="form-inline">
            <button class="btn btn-secondary my-2 my-sm-0" type="submit"> <a href="index.php" id="linkInicio">Cerrar Sesión</a></button>
        </form>
    </nav>
    <?php  if(isset($_SESSION['mensaje'])){ ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?= $_SESSION['mensaje']?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                 <span aria-hidden="true">&times;</span>
                </button>
            </div>
        
    <?php } ?>
    <div style="height: 30px;"></div>

    <form action="Agregar.php" method="POST" id="FormatoPreguntasRiesgos">
        <div class="form-group">
             <label for="formGroupExampleInput">Razón social de la Empresa: </label> <br>
             <input type="text" class="form-control" name="empresa" id="InputEmpresa" placeholder="Ingresa el nombre de la empresa" require>
        </div>
        <div class="form-group">
             <label for="formGroupExampleInput">Servicios que ofrece la empresa: </label> <br>
             <input class="form-check-input" type="checkbox" name="checkservicios1" value="Desarrollo de software"  id="checkservicios1">
             <input type="hidden" id="hddservicio1" name="hddservicio1" value="0">
             <input type="hidden" id="hddnombreservicio1" name="hddnombreservicio1" value="Desarrollo de software">
             <label class="form-check-label" for="defaultCheck1" id="labeldesarrollo">
              Desarrollo de software
            </label> <br>
            <input class="form-check-input" type="checkbox" name="checkservicios2" value=" Consultoria"  id="checkservicios2">
            <input type="hidden" id="hddservicio2" name="hddservicio2" value="0">
            <input type="hidden" id="hddnombreservicio2" name="hddnombreservicio2" value="Consultoria"> 
            <label class="form-check-label" for="defaultCheck1" id="labelconsultoria">
              Consultoria
            </label> <br>
            <input class="form-check-input" type="checkbox" name="checkservicios3" value="Soporte Técnico"  id="checkservicios3">
            <input type="hidden" id="hddservicio3" name="hddservicio3" value="0">
            <input type="hidden" id="hddnombreservicio3" name="hddnombreservicio3" value="Soporte Técnico"> 
            <label class="form-check-label" for="defaultCheck1" id="labelsoporte">
              Soporte Técnico
            </label> <br>
            <input class="form-check-input" type="checkbox" name="checkservicios4" value="Mantenimiento e infraestructura"  id="checkservicios4">
            <input type="hidden" id="hddservicio4" name="hddservicio4" value="0">
            <input type="hidden" id="hddnombreservicio4" name="hddnombreservicio4" value="Mantenimiento e infraestructura">  
            <label class="form-check-label" for="defaultCheck1" id="labelmantenimiento">
              Mantenimiento
            </label> <br>
            <input class="form-check-input" type="checkbox" name="checkservicios7" value="Infraesructura"  id="checkservicios7">
            <input type="hidden" id="hddservicio7" name="hddservicio7" value="0">
            <input type="hidden" id="hddnombreservicio7" name="hddnombreservicio7" value="Infraesructura">  
            <label class="form-check-label" for="defaultCheck1" id="labelinfraesructura">
              Infraesructura
            </label> <br>
            <input class="form-check-input" type="checkbox" name="checkservicios5" value="Seguridad de datos"  id="checkservicios5">
            <input type="hidden" id="hddservicio5" name="hddservicio5" value="0">
            <input type="hidden" id="hddnombreservicio5" name="hddnombreservicio5" value="Seguridad de datos">  
            <label class="form-check-label" for="defaultCheck1" id="labelseguridad">
              Seguridad de datos
            </label> <br>
            <input class="form-check-input" type="checkbox" name="checkservicios6" value="Proyectos de Innovación"  id="checkservicios6">
            <input type="hidden" id="hddservicio6" name="hddservicio6" value="0">
            <input type="hidden" id="hddnombreservicio6" name="hddnombreservicio6" value="Proyectos de Innovación">  
            <label class="form-check-label" for="defaultCheck1" id="labelinnovacion">
              Proyectos de Innovación
            </label>            
        </div>
        <div class="form-group">
             <label for="formGroupExampleInput">¿Cuántos años lleva en el mercado la empresa? </label> <br>
             <input type="number" class="form-control" name="años" id="InputEmpresa" placeholder="Ingresa los años de la empresa" require>
        </div>
        <div class="form-group">
        <label for="exampleFormControlSelect1">¿Cuántas personas conforman la empresa?</label>
        <select  name="personas" class="form-control" id="SelectPersonal" require>
          <option value="Menos de 10 Personas">Menos de 10 personas</option>
          <option value="Entre 11 y 50 personas">Entre 11 y 50 personas</option>
          <option value="Entre 51 y 200 personas">Entre 51 y 200 personas</option>
          <option value="Más de 200 personas">Más de 200 personas</option>
        </select>
        </div>
        <div class="form-group">
             <label for="formGroupExampleInput">¿La empresa cuenta con un plan de formación tecnologica para sus empleados? </label> <br>
             <select class="form-control" id="capacitacionesPersonal" name="capacitacionesPersonal" Required>
              <option value="Si">Sí</option>
              <option value="No">No</option>
             </select>
            </div>
    <div class="form-group" multiple>
    <label for="exampleFormControlSelect1">¿Con qué tecnologías trabaja la empresa y cuantos años lleva utilizandolas?</label> <br>
    <table class="table table-striped" id="tablaLenguajes">
    <input type="button" class="btn btn-secondary" name="botonAgregarLenguaje" value="Agregar Tecnología" id="botonAgregarLenguaje">
      <tbody>
         <tr>
          <th>Tecnología</th>
          <th>Años de experiencia</th>
          <td><input type="hidden"></td>         
        </tr>
        <tr>
          <th scope="row">
          <div class="form-check">
            <input class="form-check-input" type="checkbox" name="checklenguaje1" value="Java"  id="checklenguaje1">
            <input type="hidden" id="hddlenguaje1" name="hddlenguaje1" value="0">
            <input type="hidden" id="hddnombrelenguaje1" name="hddnombrelenguaje1" value="Java">
            <label class="form-check-label" for="defaultCheck1">
              Java
            </label>
          </div>
          </th>
          <td>
          <div class="form-group">
            <input type="number" class="form-control" name="selcalificacion1" id="selcalificacion1" placeholder="Años de experiencia" require>
          </div>
          </td>
        </tr>
        <tr>
        <th scope="row">
          <div class="form-check">
            <input class="form-check-input" type="checkbox" name="checklenguaje2" value="Python" id="checklenguaje2">
            <input type="hidden" id="hddlenguaje2" name="hddlenguaje2" value="0">
            <input type="hidden" id="hddnombrelenguaje2" name="hddnombrelenguaje2" value="Python">
            <label class="form-check-label" for="defaultCheck1">
              Python
            </label>
          </div>
          </th>
          <td>
          <div class="form-group">
            <input type="number" class="form-control" name="selcalificacion2" id="selcalificacion2" placeholder="Años de experiencia" require>
          </div>
          </td>
        </tr>
        <tr>
        <th scope="row">
          <div class="form-check">
            <input class="form-check-input" type="checkbox" name="checklenguaje3" value="C#" id="checklenguaje3">
            <input type="hidden" id="hddlenguaje3" name="hddlenguaje3" value="0">
            <input type="hidden" id="hddnombrelenguaje3" name="hddnombrelenguaje3" value="C#">
            <label class="form-check-label" for="defaultCheck1">
              C#
            </label>
          </div>
          </th>
          <td>
          <div class="form-group">
            <input type="number" class="form-control" name="selcalificacion3" id="selcalificacion3" placeholder="Años de experiencia" require>
          </div>
          </td>
        </tr>
        <tr>
        <th scope="row">
          <div class="form-check">
            <input class="form-check-input" type="checkbox" name="checklenguaje4" value="C++" id="checklenguaje4">
            <input type="hidden" id="hddlenguaje4" name="hddlenguaje4" value="0">
            <input type="hidden" id="hddnombrelenguaje4" name="hddnombrelenguaje4" value="C++">
            <label class="form-check-label" for="defaultCheck1">
              C++
            </label>
          </div>
          </th>
          <td>
          <div class="form-group">
            <input type="number" class="form-control" name="selcalificacion4" id="selcalificacion4" placeholder="Años de experiencia" require>
          </div>
          </td>
        </tr>
        <tr>
        <th scope="row">
          <div class="form-check">
            <input class="form-check-input" type="checkbox" name="checklenguaje5" value="Mysql" id="checklenguaje5">
            <input type="hidden" id="hddlenguaje5" name="hddlenguaje5" value="0">
            <input type="hidden" id="hddnombrelenguaje5" name="hddnombrelenguaje5" value="Mysql">
            <label class="form-check-label" for="defaultCheck1">
              Mysql
            </label>
          </div>
          </th>
          <td>
          <div class="form-group">
            <input type="number" class="form-control" name="selcalificacion5" id="selcalificacion5" placeholder="Años de experiencia" require>
          </div>
          </td>
        </tr>
        <tr>
        <th scope="row">
          <div class="form-check">
            <input class="form-check-input" type="checkbox" name="checklenguaje6" value="PHP" id="checklenguaje6">
            <input type="hidden" id="hddlenguaje6" name="hddlenguaje6" value="0">
            <input type="hidden" id="hddnombrelenguaje6" name="hddnombrelenguaje6" value="PHP">
            <label class="form-check-label" for="defaultCheck1">
              PHP
            </label>
          </div>
          </th>
          <td>
          <div class="form-group">
            <input type="number" class="form-control" name="selcalificacion6" id="selcalificacion6" placeholder="Años de experiencia" require>
          </div>
          </td>
        </tr>
       
      </tbody>
    </table>
    <input type="hidden" id="hddcantnuevos" name="hddcantnuevos" value="0" />
    </div>
    <input type="button" class="btn btn-primary" name="botonGuardar" value="Guardar" id="botonGuardar">
    </form>
    <div style="height: 50px;"></div>
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

    <script type="text/javascript">
      var g_cont=0;
      document.write(g_cont);
      $("#botonGuardar").click(function() {
        $("#hddlenguaje1").val($("#checklenguaje1").is(":checked") ? 1 : 0);
        $("#hddlenguaje2").val($("#checklenguaje2").is(":checked") ? 1 : 0);
        $("#hddlenguaje3").val($("#checklenguaje3").is(":checked") ? 1 : 0);
        $("#hddlenguaje4").val($("#checklenguaje4").is(":checked") ? 1 : 0);
        $("#hddlenguaje5").val($("#checklenguaje5").is(":checked") ? 1 : 0);
        $("#hddlenguaje6").val($("#checklenguaje6").is(":checked") ? 1 : 0);
        $("#hddcantnuevos").val(g_cont);
        $("#hddservicio1").val($("#checkservicios1").is(":checked") ? 1 : 0);
        $("#hddservicio2").val($("#checkservicios2").is(":checked") ? 1 : 0);
        $("#hddservicio3").val($("#checkservicios3").is(":checked") ? 1 : 0);
        $("#hddservicio4").val($("#checkservicios4").is(":checked") ? 1 : 0);
        $("#hddservicio5").val($("#checkservicios5").is(":checked") ? 1 : 0);
        $("#hddservicio6").val($("#checkservicios6").is(":checked") ? 1 : 0);
        $("#hddservicio7").val($("#checkservicios7").is(":checked") ? 1 : 0);
        
        $("#FormatoPreguntasRiesgos").submit();
      });
      $(document).ready(function(){
        $('#botonAgregarLenguaje').click(function(){
          agregar();
        });
      });
      function agregar(){
        var fila =
          '<tr>' +
            '<td>' +
              '<input type="text" class="form-control" name="lenguaje' + g_cont + '" id="lenguaje' + g_cont + '" placeholder="Ingresa la tecnología" maxlength="150">' +
            '</td>' +
            '<td>' +
            '<input type="number" class="form-control" name="selcalificacion' + g_cont + '" id="selcalificacion' + g_cont + '" placeholder="Años de experiencia" require>' +
            '</td>' +
          '</tr>';
          g_cont++;
        $('#tablaLenguajes').append(fila);
        
      }
    </script>
</body>
</html>