<?php
   @session_start();
   include_once("db/conexion.php");

   $con = obtener_conexion();
   $correo = $_SESSION["correo"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="StylesVerProyectos.css">

    <!-- Font awesome 5 (iconos) -->
    <script src="https://kit.fontawesome.com/4a20e1c69f.js"></script>

    <title>Prueba</title>
</head>
<body>
    <nav class="navbar navbar-light bg-light" id="barraNavegacion" >
        <a class="navbar-brand" id="imagenLogo"  href="AreaPersonal.php"> <img src="imagensinfondo.png" alt="" srcset="" id="imagenLogo1"></a>
        <a class="navbar-brand" id="logo" href="AreaPersonal.php"> Detección de los Riesgos <br>
        <p id="subtitulo">En las etapas de pre análisis y análisis</p></a>
        <form class="form-inline" id="cajitaboton">
            <button class="btn btn-secondary my-2 my-sm-0" type="submit"> <a href="index.php" id="linkInicio">Cerrar Sesión</a></button>
        </form>
    </nav>
    <div style="height: 75px;"></div>
    <?php  if(isset($_SESSION['mensaje'])){ ?>
            <div class="alert alert-<?= $_SESSION['tipo_mensaje']; ?> alert-dismissible fade show" role="alert">
                <?= $_SESSION['mensaje']?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                 <span aria-hidden="true">&times;</span>
                </button>
            </div>
    <?php  } ?>
    <div>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th scope="col">Nombre Proyecto</th>
                    <th scope="col">Descripcion</th>
                    <th scope="col">Acción</th>
                </tr>
            </thead>
            <tbody> 
                <?php
                    //consulta a la base de datos
                    $sql = "SELECT * FROM proyecto
                            WHERE CorreoEmpresa = '$correo'";
                    $con = obtener_conexion();
                    $resultado = mysqli_query($con,$sql); 
                   
                    $contador = mysqli_num_rows($resultado);
                    while($filas=mysqli_fetch_array($resultado)){ //mientras halla datos en la variable resultados 
                        ?>
                        <tr>
                            <td><?php echo $filas['Nombre']?></td>
                            <td><?php echo $filas['Descripcion']?></td>
                            <td>
                                <a href="verProyectoSeleccionado.php?id=<?php echo $filas['ID']?>" class="btn btn-secondary"> Ver Proyecto
                                     <i class="fas fa-eye"></i> 
                                </a>
                                <a href="VerRiesgosProyecto.php?id=<?php echo $filas['ID']?>" class="btn btn-secondary"> Ver Riesgos
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="eliminarProyectos.php?id=<?php echo $filas['ID']?>" class="btn btn-danger"> Eliminar Proyecto
                                    <i class="far fa-trash-alt"></i>
                                </a>
                            </td>
                        </tr>  
                    <?php } ?>                     
            </tbody>
        </table> 
        <a href="AreaPersonal.php" name="salida" id="salida" class="btn btn-primary">Página Inicio</a>

    </div>
    
    <div style="height: 75px;"></div>


  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>    
</body>
</html>